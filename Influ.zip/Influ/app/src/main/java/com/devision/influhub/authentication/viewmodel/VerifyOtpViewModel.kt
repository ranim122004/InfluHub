package com.devision.influhub.authentication.viewmodel

import android.content.Context
import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.devision.influhub.authentication.model.VerifyOtpRequest
import com.devision.influhub.authentication.model.VerifyOtpResponse
import com.devision.influhub.network.RetrofitBuilder
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class VerifyOtpViewModel : ViewModel() {

    val verificationStatus = MutableLiveData<String>()
    val isSuccess = MutableLiveData<Boolean>()

    fun verifyOtp(context: Context, email: String, code: String) {
        val request = VerifyOtpRequest(email, code)
        val apiService = RetrofitBuilder.getApiService(context)

        apiService.verifyOtp(request).enqueue(object : Callback<VerifyOtpResponse> {
            override fun onResponse(
                call: Call<VerifyOtpResponse>,
                response: Response<VerifyOtpResponse>
            ) {
                if (response.isSuccessful && response.body() != null) {
                    verificationStatus.postValue("OTP verified successfully!")
                    isSuccess.postValue(true)
                    Log.d("VerifyOtpViewModel", "Verification success: ${response.body()}")
                } else {
                    val errorBody = response.errorBody()?.string()
                    val errorMessage =
                        "Verification failed: ${response.code()} - ${response.message()} - $errorBody"
                    verificationStatus.postValue(errorMessage)
                    isSuccess.postValue(false)
                    Log.e("VerifyOtpViewModel", errorMessage)
                }
            }

            override fun onFailure(call: Call<VerifyOtpResponse>, t: Throwable) {
                val errorMessage = "Network error: ${t.message}"
                verificationStatus.postValue(errorMessage)
                isSuccess.postValue(false)
                Log.e("VerifyOtpViewModel", "API call failed: $errorMessage", t)
            }
        })
    }

    fun resendOtp(context: Context, email: String) {
        val apiService = RetrofitBuilder.getApiService(context)
        val requestBody = mapOf("Email" to email)

        apiService.resendOtp(requestBody).enqueue(object : Callback<Void> {
            override fun onResponse(call: Call<Void>, response: Response<Void>) {
                if (response.isSuccessful) {
                    verificationStatus.postValue("OTP resent successfully.")
                    Log.d("VerifyOtpViewModel", "OTP resent to $email")
                } else {
                    val error = response.errorBody()?.string()
                    verificationStatus.postValue("Failed to resend OTP: ${response.code()} - $error")
                    Log.e("VerifyOtpViewModel", "Resend failed: $error")
                }
            }

            override fun onFailure(call: Call<Void>, t: Throwable) {
                val errorMessage = "Network error: ${t.message}"
                verificationStatus.postValue(errorMessage)
                Log.e("VerifyOtpViewModel", errorMessage, t)
            }
        })
    }
}
