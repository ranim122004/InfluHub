import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.devision.influhub.dashboard.model.HotPicksModel
import com.devision.influhub.databinding.ItemHotpickerBinding

class AllHotPicksAdapter(private val hotPicksList: List<HotPicksModel>) :
    RecyclerView.Adapter<AllHotPicksAdapter.HotPicksViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): HotPicksViewHolder {
        val binding = ItemHotpickerBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return HotPicksViewHolder(binding)
    }

    override fun onBindViewHolder(holder: HotPicksViewHolder, position: Int) {
        val hotPick = hotPicksList[position]
        Glide.with(holder.binding.image.context)
            .load(hotPick.image)
            .into(holder.binding.image)

        holder.binding.username.text = hotPick.username
    }

    override fun getItemCount(): Int = hotPicksList.size

    class HotPicksViewHolder(val binding: ItemHotpickerBinding) : RecyclerView.ViewHolder(binding.root)
}
