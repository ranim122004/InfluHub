package com.devision.influhub.authentication.model

data class User(
    val username: String,
    val Email: String,
    val userType: String,
    val _id: String,
    val Image: String? = null,
    val PhoneNumber: String? = null,
    val Industry: String? = null,
    val Type: String? = null,
    val Capital: String? = null,
    val DigitalPresence: String? = null
)
