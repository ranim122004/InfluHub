package com.devision.influhub.dashboard.view

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.devision.influhub.R
import com.devision.influhub.dashboard.model.FeaturedItem

class AllFeaturedAdapter(private val items: List<FeaturedItem>) :
    RecyclerView.Adapter<AllFeaturedAdapter.ViewHolder>() {

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val featuredName: TextView = itemView.findViewById(R.id.FeaturedName)
        val featuredImage: ImageView = itemView.findViewById(R.id.FeaturedImage)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_featured, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = items[position]
        holder.featuredName.text = item.username
        Glide.with(holder.itemView.context)
            .load(item.image)
            .into(holder.featuredImage)
    }

    override fun getItemCount(): Int = items.size
}