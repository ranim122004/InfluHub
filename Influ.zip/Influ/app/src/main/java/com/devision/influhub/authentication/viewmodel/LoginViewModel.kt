package com.devision.influhub.authentication.viewmodel

import android.content.Context
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.devision.influhub.authentication.model.LoginRequest
import com.devision.influhub.authentication.model.LoginResponse
import com.devision.influhub.authentication.model.SocialLoginRequest
import com.devision.influhub.authentication.model.SocialLoginResponse
import com.devision.influhub.network.RetrofitBuilder
import com.devision.influhub.util.UserContext
import com.google.gson.Gson
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class LoginViewModel : ViewModel() {

    val loginStatus = MutableLiveData<String>()
    val loginSuccess = MutableLiveData<Boolean>()
    val userType = MutableLiveData<String>()
    val userId = MutableLiveData<String>()

    fun login(context: Context, username: String, password: String) {
        val request = LoginRequest(username, password)
        val apiService = RetrofitBuilder.getApiService(context)

        apiService.loginUser(request).enqueue(object : Callback<LoginResponse> {
            override fun onResponse(call: Call<LoginResponse>, resp: Response<LoginResponse>) {
                if (resp.isSuccessful && resp.body() != null) {
                    val user = resp.body()!!.user
                    val token = resp.body()!!.token

                    userType.postValue(user.userType)
                    userId.postValue(user._id)

                    // save in memory
                    UserContext.setProperty("profile", Gson().toJson(user))
                    UserContext.setProperty("accessToken", token)

                    // save in prefs
                    val sp = context.getSharedPreferences("user_pref", Context.MODE_PRIVATE)
                    sp.edit().apply {
                        putString("token", token)
                        putString("userId", user._id)
                        putString("userType", user.userType)
                        putString("saved_email", user.Email)
                        putString("saved_username", user.username)
                        apply()
                    }

                    loginStatus.postValue("Login successful")
                    loginSuccess.postValue(true)
                } else {
                    val err = resp.errorBody()?.string() ?: resp.message() ?: "Unknown error"
                    loginStatus.postValue("Login failed: $err")
                    loginSuccess.postValue(false)
                }
            }

            override fun onFailure(call: Call<LoginResponse>, t: Throwable) {
                loginStatus.postValue("Network error: ${t.message}")
                loginSuccess.postValue(false)
            }
        })
    }

    /** Google via backend /api/auth/social-login (provider+accessToken -> {user, token}) */
    fun loginWithGoogle(context: Context, accessToken: String) {
        val apiService = RetrofitBuilder.getApiService(context)
        val body = SocialLoginRequest(
            provider = "google",
            accessToken = accessToken
        )

        apiService.socialLogin(body).enqueue(object : Callback<SocialLoginResponse> {
            override fun onResponse(
                call: Call<SocialLoginResponse>,
                resp: Response<SocialLoginResponse>
            ) {
                if (resp.isSuccessful && resp.body() != null) {
                    val payload = resp.body()!!
                    val user = payload.user
                    val token = payload.token

                    // expose to observers
                    userType.postValue(user.userType ?: "")
                    userId.postValue(user._id ?: "")

                    // save in memory
                    UserContext.setProperty("profile", Gson().toJson(user))
                    UserContext.setProperty("accessToken", token)

                    // save in prefs
                    val sp = context.getSharedPreferences("user_pref", Context.MODE_PRIVATE)
                    sp.edit().apply {
                        putString("token", token)
                        putString("userId", user._id ?: "")
                        putString("userType", user.userType ?: "")
                        putString("saved_email", user.Email ?: "")
                        putString("saved_username", user.username ?: "")
                        apply()
                    }

                    loginStatus.postValue("Google login successful")
                    loginSuccess.postValue(true)
                } else {
                    val err = resp.errorBody()?.string() ?: resp.message() ?: "Unknown error"
                    loginStatus.postValue("Google login failed: $err")
                    loginSuccess.postValue(false)
                }
            }

            override fun onFailure(call: Call<SocialLoginResponse>, t: Throwable) {
                loginStatus.postValue("Network error: ${t.message}")
                loginSuccess.postValue(false)
            }
        })
    }
}
