package com.devision.influhub.authentication.view

import android.app.AlertDialog
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import com.devision.influhub.R
import com.devision.influhub.authentication.viewmodel.VerifyOtpViewModel
import com.devision.influhub.databinding.ActivityVerifyEmailBinding

class VerifyEmailFragment : Fragment() {

    private var _binding: ActivityVerifyEmailBinding? = null
    private val binding get() = _binding!!
    private val verifyOtpViewModel: VerifyOtpViewModel by viewModels()

    private var userEmail: String? = null

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = ActivityVerifyEmailBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        userEmail = arguments?.getString("email")
        Log.d("VerifyEmailFragment", "Email received: $userEmail")

        setupListeners()
        observeViewModel()
    }

    private fun setupListeners() {
        binding.backIcon.setOnClickListener {
            requireActivity().onBackPressedDispatcher.onBackPressed()
        }

        binding.continueButton.setOnClickListener {
            val code = binding.codeEditText.text.toString().trim()

            if (code.isEmpty()) {
                Toast.makeText(requireContext(), "Please enter the OTP code.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (userEmail.isNullOrEmpty()) {
                Toast.makeText(requireContext(), "Email is missing.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            binding.resendOtpText.setOnClickListener {
                if (userEmail.isNullOrEmpty()) {
                    Toast.makeText(requireContext(), "Email is missing.", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }

                binding.verifyProgressBar.visibility = View.VISIBLE
                verifyOtpViewModel.resendOtp(requireContext(), userEmail!!)
            }

            binding.continueButton.text = ""
            binding.continueButton.isEnabled = false
            binding.verifyProgressBar.visibility = View.VISIBLE

            Log.d("VerifyEmailFragment", "Verifying email: $userEmail with code: $code")
            verifyOtpViewModel.verifyOtp(requireContext(), userEmail!!, code)
        }
    }

    private fun observeViewModel() {
        verifyOtpViewModel.verificationStatus.observe(viewLifecycleOwner) { message ->
            Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show()

            binding.verifyProgressBar.visibility = View.GONE
            binding.continueButton.text = "CONTINUE"
            binding.continueButton.isEnabled = true
        }

        verifyOtpViewModel.isSuccess.observe(viewLifecycleOwner) { success ->
            if (success) {
                showSuccessDialog()
            }
        }
    }

    private fun showSuccessDialog() {
        AlertDialog.Builder(requireContext())
            .setTitle("Verification Successful")
            .setMessage("Your email has been verified successfully. Click OK to continue to onboarding.")
            .setPositiveButton("OK") { dialog, _ ->
                dialog.dismiss()
                val fragment = ProfileOnboardingFragment()
                val bundle = Bundle()
                bundle.putString("email", userEmail)

                fragment.arguments = bundle

                parentFragmentManager.beginTransaction()
                    .replace(R.id.fragmentContainer, fragment)
                    .addToBackStack(null)
                    .commit()
            }
            .setCancelable(false)
            .show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
