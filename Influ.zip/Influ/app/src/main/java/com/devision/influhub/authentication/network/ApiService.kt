package com.devision.influhub.network

import com.devision.influhub.authentication.model.*
import com.devision.influhub.dashboard.model.*
import okhttp3.MultipartBody
import okhttp3.RequestBody
import okhttp3.ResponseBody
import retrofit2.Call
import retrofit2.http.*

interface ApiService {

    //authentication
    @Headers("Content-Type: application/json")
    @POST("authentication/signup")
    fun registerUser(@Body request: RegisterRequest): Call<RegisterResponse>

    @POST("verify-otp")
    @Headers("Content-Type: application/json")
    fun verifyOtp(@Body request: VerifyOtpRequest): Call<VerifyOtpResponse>

    @POST("login")
    @Headers("Content-Type: application/json")
    fun loginUser(@Body request: LoginRequest): Call<LoginResponse>

    @POST("forgot-password")
    @Headers("Content-Type: application/json")
    fun sendOtp(@Body request: ForgotPasswordRequest): Call<ForgotPasswordResponse>

    @POST("verify-otp-reset")
    @Headers("Content-Type: application/json")
    fun verifyOtpReset(@Body request: VerifyOtpResetRequest): Call<GenericResponse>

    @POST("reset-password")
    @Headers("Content-Type: application/json")
    fun resetPassword(@Body request: ResetPasswordRequest): Call<GenericResponse>

    @POST("api/authentication/resend-otp")
    fun resendOtp(@Body body: Map<String, String>): Call<Void>

    @POST("profile-onboarding-submit")
    @Headers("Content-Type: application/json")
    suspend fun submitProfileOnboarding(@Body request: ProfileOnboardingRequest): GenericResponse

    @GET("profile-onboarding")
    fun getProfileOnboardingOptions(): Call<Map<String, Any>>

    @GET("profile-onboarding-submit/{id}")
    fun getUserById(@Path("id") userId: String): Call<UserResponse>

    @POST("auth/social-login")
    @Headers("Content-Type: application/json")
    fun socialLogin(@Body body: com.devision.influhub.authentication.model.SocialLoginRequest)
            : Call<com.devision.influhub.authentication.model.SocialLoginResponse>

    @Multipart
    @POST("updating-profile")
    fun uploadProfileImage(
        @Part image: MultipartBody.Part,
        @Part("firstName") firstName: RequestBody,
        @Part("lastName") lastName: RequestBody,
        @Header("id") userId: String
    ): Call<ResponseBody>

    @POST("change-password")
    @Headers("Content-Type: application/json")
    fun changePassword(
        @Header("userId") userId: String,
        @Body body: Map<String, String>
    ): Call<ResponseBody>

    @DELETE("delete")
    fun deleteAccount(
        @Header("Authorization") authToken: String
    ): Call<ResponseBody>

    @POST("change-language")
    @Headers("Content-Type: application/json")
    fun changeLanguage(
        @Header("Authorization") token: String,
        @Body body: Map<String, String>
    ): Call<ResponseBody>

    //  ADDRESSES

    @POST("user/addresses")
    @Headers("Content-Type: application/json")
    fun saveAddress(
        @Header("Authorization") token: String,
        @Body body: RequestBody
    ): Call<ResponseBody>

    @GET("user/all-addresses")
    fun getUserAddresses(
        @Header("Authorization") token: String
    ): Call<AddressesResponse>

    @DELETE("user/address/{id}")
    fun deleteAddress(
        @Header("Authorization") token: String,
        @Path("id") addressId: String
    ): Call<ResponseBody>

    @PUT("user/address/{id}")
    @Headers("Content-Type: application/json")
    fun updateAddress(
        @Header("Authorization") token: String,
        @Path("id") addressId: String,
        @Body updatedData: Map<String, String>
    ): Call<ResponseBody>

    // DASHBOARD

    @GET("retailer/featured-suppliers")
    fun getFeatured(@Header("user-id") userId: String): Call<List<FeaturedItem>>

    @GET("getAllHotPickedSuppliers")
    fun getHotPickedSuppliers(@Header("user-id") userId: String): Call<List<HotPicksModel>>

    @GET("getAllLastChanceSuppliers")
    fun getLastChance(@Header("user-id") userId: String): Call<List<LastChanceModel>>

    @POST("retailer/competitors")
    fun getCompetitorsForRetailer(@Header("user-id") userId: String): Call<List<CompetitorModel>>

    @GET("supplier/featured-suppliers")
    fun getSupplierFeatured(@Header("user-id") userId: String): Call<List<FeaturedItem>>

    @GET("getAllLowInStockSuppliers")
    fun getAllLowStockItems(@Header("user-id") userId: String): Call<List<LowStockItem>>

    @POST("supplier/competitors")
    fun getSupplierCompetitors(@Header("user-id") userId: String): Call<List<CompetitorModel>>
}
