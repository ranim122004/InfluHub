package com.devision.influhub.dashboard.model

data class AddressesResponse(
    val addresses: List<AddressItem> = emptyList()
)
