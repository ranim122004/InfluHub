package com.devision.influhub.dashboard.view

import android.content.Context
import android.graphics.Typeface
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import com.devision.influhub.R
import com.devision.influhub.network.RetrofitBuilder
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.RequestBody
import okhttp3.ResponseBody
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class LanguageBottomSheetFragment : BottomSheetDialogFragment() {

    private lateinit var langEn: TextView
    private lateinit var langAr: TextView
    private lateinit var langFr: TextView
    private lateinit var enIndicator: View

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_language_sheet, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        langEn = view.findViewById(R.id.lang_en)
        langAr = view.findViewById(R.id.lang_ar)
        langFr = view.findViewById(R.id.lang_fr)
        enIndicator = view.findViewById(R.id.en_selected_indicator)

        langEn.setOnClickListener { changeLanguage("en") }
        langAr.setOnClickListener { changeLanguage("ar") }
        langFr.setOnClickListener { changeLanguage("fr") }
    }

    private fun changeLanguage(languageCode: String) {
        val sharedPref = requireContext().getSharedPreferences("user_pref", Context.MODE_PRIVATE)
        val token = sharedPref.getString("token", null)

        if (token.isNullOrEmpty()) {
            Toast.makeText(context, "Authentication token not found", Toast.LENGTH_SHORT).show()
            return
        }

        val body = mapOf("language" to languageCode)
        val apiService = RetrofitBuilder.getApiService(requireContext())
        apiService.changeLanguage("Bearer $token", body).enqueue(object : Callback<ResponseBody> {
            override fun onResponse(call: Call<ResponseBody>, response: Response<ResponseBody>) {
                if (response.isSuccessful) {
                    updateUI(languageCode)
                    Toast.makeText(context, "Language updated to $languageCode", Toast.LENGTH_SHORT).show()
                    dismiss()
                } else {
                    Toast.makeText(context, "Failed to update language", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onFailure(call: Call<ResponseBody>, t: Throwable) {
                Toast.makeText(context, "Network error: ${t.message}", Toast.LENGTH_SHORT).show()
            }
        })
    }

    private fun updateUI(selected: String) {
        when (selected) {
            "en" -> {
                langEn.setTypeface(null, Typeface.BOLD)
                langAr.setTypeface(null, Typeface.NORMAL)
                langFr.setTypeface(null, Typeface.NORMAL)
                enIndicator.visibility = View.VISIBLE
            }
            "ar" -> {
                langEn.setTypeface(null, Typeface.NORMAL)
                langAr.setTypeface(null, Typeface.BOLD)
                langFr.setTypeface(null, Typeface.NORMAL)
                enIndicator.visibility = View.GONE
            }
            "fr" -> {
                langEn.setTypeface(null, Typeface.NORMAL)
                langAr.setTypeface(null, Typeface.NORMAL)
                langFr.setTypeface(null, Typeface.BOLD)
                enIndicator.visibility = View.GONE
            }
        }
    }
}
