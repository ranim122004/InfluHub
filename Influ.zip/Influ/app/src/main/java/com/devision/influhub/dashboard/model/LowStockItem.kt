// com.example.influ.dashboard.model.LowStockItem.kt
package com.devision.influhub.dashboard.model
import kotlinx.parcelize.Parcelize
import android.os.Parcelable

@Parcelize
data class LowStockItem(
    val id: String?,
    val username: String?,
    val image: String?
) : Parcelable

