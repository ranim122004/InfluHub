package com.devision.influhub.authentication.model

data class GenericResponse(
    val message: String
)
