package com.devision.influhub.dashboard.view

import android.content.Context
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.devision.influhub.R
import com.devision.influhub.authentication.adapter.SupplierCompetitorAdapter
import com.devision.influhub.dashboard.model.CompetitorModel
import com.devision.influhub.dashboard.model.FeaturedItem
import com.devision.influhub.dashboard.model.LowStockItem
import com.devision.influhub.databinding.FragmentSupplierDashboardBinding
import com.devision.influhub.network.RetrofitBuilder
import com.devision.influhub.view.MessagesFragment
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class SupplierDashboardFragment : Fragment() {

    private var _binding: FragmentSupplierDashboardBinding? = null
    private val binding get() = _binding!!

    private var userId: String? = null
    private lateinit var featuredAdapter: FeaturedSupplierAdapter
    private lateinit var lowStockAdapter: LowStockAdapter
    private lateinit var competitorAdapter: SupplierCompetitorAdapter

    private var fetchedLowStockList: List<LowStockItem> = emptyList()
    private var fetchedFeaturedList: List<FeaturedItem> = emptyList()
    private var fetchedCompetitorList: List<CompetitorModel> = emptyList()

    private var completedCalls = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Get userId from arguments or fallback to SharedPreferences
        userId = arguments?.getString("userId") ?: run {
            val sharedPref = requireContext().getSharedPreferences("user_pref", Context.MODE_PRIVATE)
            sharedPref.getString("userId", null)
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentSupplierDashboardBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        showLoader()
        completedCalls = 0

        setupAdapters()
        fetchSupplierData()

        setupBottomNav()
    }

    private fun setupAdapters() {
        featuredAdapter = FeaturedSupplierAdapter(mutableListOf()) {
            val fragment = AllFeaturedSuppliersFragment.newInstance(ArrayList(fetchedFeaturedList))
            parentFragmentManager.beginTransaction()
                .replace(R.id.fragmentContainer, fragment)
                .addToBackStack(null)
                .commit()
        }
        binding.featuredRecycler.layoutManager =
            LinearLayoutManager(requireContext(), LinearLayoutManager.HORIZONTAL, false)
        binding.featuredRecycler.adapter = featuredAdapter

        lowStockAdapter = LowStockAdapter(mutableListOf()) {
            val fragment = AllLowStockFragment.newInstance(ArrayList(fetchedLowStockList))
            parentFragmentManager.beginTransaction()
                .replace(R.id.fragmentContainer, fragment)
                .addToBackStack(null)
                .commit()
        }
        binding.lowinstickRecyclerView.layoutManager =
            LinearLayoutManager(requireContext(), LinearLayoutManager.HORIZONTAL, false)
        binding.lowinstickRecyclerView.adapter = lowStockAdapter

        competitorAdapter = SupplierCompetitorAdapter(mutableListOf()) {}
        binding.competitorRecycler.layoutManager =
            LinearLayoutManager(requireContext(), LinearLayoutManager.HORIZONTAL, false)
        binding.competitorRecycler.adapter = competitorAdapter
    }

    private fun fetchSupplierData() {
        userId?.let {
            fetchFeatured(it)
            fetchLowStock(it)
            fetchCompetitors(it)
        } ?: showToast("User ID not found. Please log in again.")
    }

    private fun fetchFeatured(userId: String) {
        val apiService = RetrofitBuilder.getApiService(requireContext())
        apiService.getSupplierFeatured(userId).enqueue(object : Callback<List<FeaturedItem>> {
            override fun onResponse(call: Call<List<FeaturedItem>>, response: Response<List<FeaturedItem>>) {
                if (response.isSuccessful) {
                    fetchedFeaturedList = response.body()?.filter { it.id != null } ?: emptyList()
                    featuredAdapter.updateList(fetchedFeaturedList.take(10).toMutableList())
                } else {
                    showToast("Failed to load featured suppliers")
                }
                hideLoaderWhenDone()
            }

            override fun onFailure(call: Call<List<FeaturedItem>>, t: Throwable) {
                showToast("Network error: ${t.message}")
                Log.e("SupplierDashboard", "Featured error", t)
                hideLoaderWhenDone()
            }
        })
    }

    private fun fetchLowStock(userId: String) {
        val apiService = RetrofitBuilder.getApiService(requireContext())
        apiService.getAllLowStockItems(userId).enqueue(object : Callback<List<LowStockItem>> {
            override fun onResponse(call: Call<List<LowStockItem>>, response: Response<List<LowStockItem>>) {
                if (response.isSuccessful) {
                    fetchedLowStockList = response.body()?.filter { it.id != null } ?: emptyList()
                    val maxDisplay = 10
                    val showViewAll = fetchedLowStockList.size > maxDisplay
                    val displayList = if (showViewAll) {
                        fetchedLowStockList.take(maxDisplay)
                    } else {
                        fetchedLowStockList
                    }
                    lowStockAdapter.updateList(displayList.toMutableList(), showViewAll)
                } else {
                    showToast("Failed to load low stock items")
                }
                hideLoaderWhenDone()
            }

            override fun onFailure(call: Call<List<LowStockItem>>, t: Throwable) {
                Log.e("LowStock", "Failure: ${t.message}", t)
                showToast("Network error: ${t.message}")
                hideLoaderWhenDone()
            }
        })
    }

    private fun fetchCompetitors(userId: String) {
        val apiService = RetrofitBuilder.getApiService(requireContext())
        apiService.getSupplierCompetitors(userId).enqueue(object : Callback<List<CompetitorModel>> {
            override fun onResponse(call: Call<List<CompetitorModel>>, response: Response<List<CompetitorModel>>) {
                if (response.isSuccessful) {
                    fetchedCompetitorList = response.body() ?: emptyList()
                    competitorAdapter.updateList(fetchedCompetitorList.take(10).toMutableList())
                } else {
                    showToast("Failed to load competitors")
                }
                hideLoaderWhenDone()
            }

            override fun onFailure(call: Call<List<CompetitorModel>>, t: Throwable) {
                Log.e("SupplierDashboard", "Competitors error: ${t.message}", t)
                showToast("Network error: ${t.message}")
                hideLoaderWhenDone()
            }
        })
    }

    private fun setupBottomNav() {
        val bottomNav = binding.bottomNavigationView
        bottomNav.menu.findItem(R.id.menu_dashboard).isChecked = true

        bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.menu_dashboard -> {
                    // Reload Supplier Dashboard
                    val fragment = SupplierDashboardFragment()
                    parentFragmentManager.beginTransaction()
                        .replace(R.id.fragmentContainer, fragment)
                        .commit()
                }
                R.id.menu_x -> navigateTo(XFragment())
                R.id.menu_messages -> navigateTo(MessagesFragment())
                R.id.menu_more -> navigateTo(MoreFragment())
            }
            true
        }
    }

    private fun showLoader() {
        binding.scrollView.visibility = View.GONE
        binding.bottomNavigation.visibility = View.GONE
        binding.loaderView.visibility = View.VISIBLE
    }

    private fun hideLoaderWhenDone() {
        completedCalls++
        if (completedCalls == 3) {
            binding.loaderView.visibility = View.GONE
            binding.scrollView.visibility = View.VISIBLE
            binding.bottomNavigation.visibility = View.VISIBLE
        }
    }

    private fun navigateTo(fragment: Fragment) {
        parentFragmentManager.beginTransaction()
            .replace(R.id.fragmentContainer, fragment)
            .addToBackStack(null)
            .commit()
    }

    private fun showToast(message: String) {
        Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
