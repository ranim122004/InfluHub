package com.devision.influhub.view

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.devision.influhub.R
import com.devision.influhub.dashboard.model.FeaturedItem

class FeaturedAdapter(
    private val items: List<FeaturedItem>,
    private val onViewAllClick: () -> Unit
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    companion object {
        private const val TYPE_FEATURED = 0
        private const val TYPE_VIEW_ALL = 1
    }

    override fun getItemCount(): Int = items.size + 1  // Show all items + View All

    override fun getItemViewType(position: Int): Int {
        return if (position < items.size) TYPE_FEATURED else TYPE_VIEW_ALL
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return if (viewType == TYPE_FEATURED) {
            val view = LayoutInflater.from(parent.context)
                .inflate(R.layout.item_featured, parent, false)
            FeaturedViewHolder(view)
        } else {
            val view = LayoutInflater.from(parent.context)
                .inflate(R.layout.item_view_all, parent, false)
            ViewAllViewHolder(view, onViewAllClick)
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        if (holder is FeaturedViewHolder && position < items.size) {
            holder.bind(items[position])
        }
    }


    class FeaturedViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val usernameTextView: TextView = itemView.findViewById(R.id.FeaturedName)
        private val imageView: ImageView = itemView.findViewById(R.id.FeaturedImage)

        fun bind(item: FeaturedItem) {
            usernameTextView.text = item.username

            Glide.with(itemView.context)
                .load(item.image)
                .into(imageView)
        }
    }

    class ViewAllViewHolder(itemView: View, onClick: () -> Unit) : RecyclerView.ViewHolder(itemView) {
        init {
            itemView.setOnClickListener { onClick() }
        }
    }
}
