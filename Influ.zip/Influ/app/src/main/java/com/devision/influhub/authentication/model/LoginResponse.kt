package com.devision.influhub.authentication.model

data class LoginResponse(
    val user: User,
    val token: String
)
