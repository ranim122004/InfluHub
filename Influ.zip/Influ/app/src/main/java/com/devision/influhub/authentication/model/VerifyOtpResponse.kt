package com.devision.influhub.authentication.model

data class VerifyOtpResponse(
    val accessToken: String,
    val refreshToken: String
)
