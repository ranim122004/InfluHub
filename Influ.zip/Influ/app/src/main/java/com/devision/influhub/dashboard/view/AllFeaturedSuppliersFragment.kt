package com.devision.influhub.dashboard.view

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import com.devision.influhub.dashboard.model.FeaturedItem
import com.devision.influhub.databinding.FragmentAllFeaturedBinding

class AllFeaturedSuppliersFragment : Fragment() {

    private var _binding: FragmentAllFeaturedBinding? = null
    private val binding get() = _binding!!

    private lateinit var adapter: FeaturedSupplierAdapter
    private lateinit var fullList: ArrayList<FeaturedItem>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val originalList = arguments?.getParcelableArrayList<FeaturedItem>("featuredList") ?: arrayListOf()

        fullList = originalList.filterNot { it.username == "View All" || it.id == null }.toCollection(ArrayList())
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentAllFeaturedBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        adapter = FeaturedSupplierAdapter(fullList) {
            // Optional: handle individual supplier click here
        }
        binding.recyclerView.layoutManager = GridLayoutManager(requireContext(), 4)
        binding.recyclerView.adapter = adapter
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    companion object {
        fun newInstance(items: ArrayList<FeaturedItem>): AllFeaturedSuppliersFragment {
            return AllFeaturedSuppliersFragment().apply {
                arguments = Bundle().apply {
                    putParcelableArrayList("featuredList", items)
                }
            }
        }
    }
}
