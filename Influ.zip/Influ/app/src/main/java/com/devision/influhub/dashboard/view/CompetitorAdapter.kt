package com.devision.influhub.dashboard.view

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.devision.influhub.dashboard.model.CompetitorModel
import com.devision.influhub.databinding.ItemCompetitorBinding

class CompetitorAdapter(private val competitors: List<CompetitorModel>) :
    RecyclerView.Adapter<CompetitorAdapter.CompetitorViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CompetitorViewHolder {
        val binding = ItemCompetitorBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return CompetitorViewHolder(binding)
    }

    override fun onBindViewHolder(holder: CompetitorViewHolder, position: Int) {
        val competitor = competitors[position]
        Glide.with(holder.binding.competitorImage.context)
            .load(competitor.image)
            .into(holder.binding.competitorImage)
        holder.binding.competitorName.text = competitor.username
    }

    override fun getItemCount(): Int = competitors.size

    class CompetitorViewHolder(val binding: ItemCompetitorBinding) :
        RecyclerView.ViewHolder(binding.root)
}
