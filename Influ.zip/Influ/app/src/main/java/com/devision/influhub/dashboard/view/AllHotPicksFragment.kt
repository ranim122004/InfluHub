package com.devision.influhub.dashboard.view

import AllHotPicksAdapter
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import com.devision.influhub.dashboard.model.HotPicksModel
import com.devision.influhub.databinding.FragmentAllHotPicksBinding

class AllHotPicksFragment : Fragment() {

    private var _binding: FragmentAllHotPicksBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentAllHotPicksBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val hotPicksList = arguments?.getParcelableArrayList<HotPicksModel>(ARG_HOT_PICKS_LIST) ?: emptyList()
        binding.allFeaturedRecyclerView.layoutManager = GridLayoutManager(requireContext(), 4)
        binding.allFeaturedRecyclerView.adapter = AllHotPicksAdapter(hotPicksList)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    companion object {
        private const val ARG_HOT_PICKS_LIST = "HOT_PICKS_LIST"

        fun newInstance(hotPicksList: ArrayList<HotPicksModel>): AllHotPicksFragment {
            val fragment = AllHotPicksFragment()
            val args = Bundle()
            args.putParcelableArrayList(ARG_HOT_PICKS_LIST, hotPicksList)
            fragment.arguments = args
            return fragment
        }
    }
}
