package com.devision.influhub.authentication.viewmodel

import android.content.Context
import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.devision.influhub.authentication.model.RegisterRequest
import com.devision.influhub.authentication.model.RegisterResponse
import com.devision.influhub.network.RetrofitBuilder
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class RegisterViewModel : ViewModel() {

    val registrationStatus = MutableLiveData<String>()
    val isSuccess = MutableLiveData<Boolean>()

    fun register(context: Context, email: String, password: String, confirmPassword: String) {
        val request = RegisterRequest(email, password, confirmPassword)
        val apiService = RetrofitBuilder.getApiService(context)
        Log.d("RegisterDebug", "Sending -> email=$email, password=$password, confirm=$confirmPassword")

        apiService.registerUser(request).enqueue(object : Callback<RegisterResponse> {
            override fun onResponse(
                call: Call<RegisterResponse>,
                response: Response<RegisterResponse>
            ) {
                if (response.isSuccessful && response.body() != null) {
                    val serverMessage = response.body()!!.message
                    registrationStatus.postValue(serverMessage)
                    isSuccess.postValue(true)
                    Log.d("RegisterDebug", "Registration success: $serverMessage")
                } else {
                    val errorBody = response.errorBody()?.string()
                    val errorMessage = "Registration failed: ${response.code()} - ${response.message()} - $errorBody"
                    registrationStatus.postValue(errorMessage)
                    isSuccess.postValue(false)
                    Log.e("RegisterDebug", errorMessage)
                }
            }

            override fun onFailure(call: Call<RegisterResponse>, t: Throwable) {
                val errorMessage = "Network error: ${t.message}"
                registrationStatus.postValue(errorMessage)
                isSuccess.postValue(false)
                Log.e("RegisterDebug", "API call failed: $errorMessage", t)
            }
        })
    }
}
