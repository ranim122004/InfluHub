package com.devision.influhub.authentication.model

data class LoginRequest(
    val username: String,
    val Password: String
)
