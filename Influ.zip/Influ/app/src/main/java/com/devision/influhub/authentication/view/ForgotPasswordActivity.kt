package com.devision.influhub.view

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import com.devision.influhub.R
import com.devision.influhub.authentication.viewmodel.ForgotPasswordViewModel
import com.devision.influhub.databinding.ActivityForgotPasswordBinding

class ForgotPasswordFragment : Fragment() {

    private var _binding: ActivityForgotPasswordBinding? = null
    private val binding get() = _binding!!
    private val viewModel: ForgotPasswordViewModel by viewModels()

    private var userEmail: String? = null

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = ActivityForgotPasswordBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        userEmail = arguments?.getString("email") // ✅ full email for backend

        binding.backIcon.setOnClickListener {
            requireActivity().onBackPressedDispatcher.onBackPressed()
        }

        binding.arrowIcon.setOnClickListener {
            val email = userEmail ?: ""
            if (email.isEmpty()) {
                Toast.makeText(requireContext(), "Email not available", Toast.LENGTH_SHORT).show()
            } else {
                viewModel.sendOtp(requireContext(), email)
            }
        }

        viewModel.statusMessage.observe(viewLifecycleOwner) { message ->
            Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show()
        }

        viewModel.navigateToOtp.observe(viewLifecycleOwner) { go ->
            if (go == true) {
                val fragment = VerifyOtpResetFragment()
                val bundle = Bundle()
                bundle.putString("email", userEmail)
                fragment.arguments = bundle

                parentFragmentManager.beginTransaction()
                    .replace(R.id.fragmentContainer, fragment)
                    .addToBackStack(null)
                    .commit()
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
