package com.devision.influhub.dashboard.view

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.devision.influhub.dashboard.model.LastChanceModel
import com.devision.influhub.databinding.LastChanceItemBinding

class AllLastChanceAdapter(private val lastChanceList: List<LastChanceModel>) :
    RecyclerView.Adapter<AllLastChanceAdapter.LastChanceViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): LastChanceViewHolder {
        val binding = LastChanceItemBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return LastChanceViewHolder(binding)
    }

    override fun onBindViewHolder(holder: LastChanceViewHolder, position: Int) {
        val item = lastChanceList[position]
        Glide.with(holder.binding.lastchanceImage.context)
            .load(item.image)
            .into(holder.binding.lastchanceImage)

        holder.binding.lastchanceName.text = item.username
    }

    override fun getItemCount(): Int = lastChanceList.size

    class LastChanceViewHolder(val binding: LastChanceItemBinding) :
        RecyclerView.ViewHolder(binding.root)
}
