package com.devision.influhub.authentication.viewmodel

import android.content.Context
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.devision.influhub.authentication.model.*
import com.devision.influhub.network.RetrofitBuilder
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class ForgotPasswordViewModel : ViewModel() {

    val statusMessage = MutableLiveData<String>()
    val navigateToOtp = MutableLiveData<Boolean>()
    val navigateToReset = MutableLiveData<Boolean>()
    val resetSuccess = MutableLiveData<Boolean>()

    fun sendOtp(context: Context, email: String) {
        val apiService = RetrofitBuilder.getApiService(context)
        val request = ForgotPasswordRequest(email)

        apiService.sendOtp(request).enqueue(object : Callback<ForgotPasswordResponse> {
            override fun onResponse(call: Call<ForgotPasswordResponse>, response: Response<ForgotPasswordResponse>) {
                if (response.isSuccessful) {
                    statusMessage.postValue("OTP sent to your email for verification")
                    navigateToOtp.postValue(true)
                } else {
                    statusMessage.postValue("Failed to send OTP: ${response.message()}")
                }
            }

            override fun onFailure(call: Call<ForgotPasswordResponse>, t: Throwable) {
                statusMessage.postValue("Network error: ${t.message}")
            }
        })
    }

    fun verifyOtp(context: Context, email: String, otp: String) {
        val apiService = RetrofitBuilder.getApiService(context)
        val request = VerifyOtpResetRequest(email, otp)

        apiService.verifyOtpReset(request).enqueue(object : Callback<GenericResponse> {
            override fun onResponse(call: Call<GenericResponse>, response: Response<GenericResponse>) {
                if (response.isSuccessful) {
                    statusMessage.postValue("OTP verified successfully")
                    navigateToReset.postValue(true)
                } else {
                    statusMessage.postValue("Invalid or expired OTP")
                }
            }

            override fun onFailure(call: Call<GenericResponse>, t: Throwable) {
                statusMessage.postValue("Network error: ${t.message}")
            }
        })
    }

    fun resetPassword(context: Context, email: String, newPassword: String) {
        val apiService = RetrofitBuilder.getApiService(context)
        val request = ResetPasswordRequest(email, newPassword)

        apiService.resetPassword(request).enqueue(object : Callback<GenericResponse> {
            override fun onResponse(call: Call<GenericResponse>, response: Response<GenericResponse>) {
                if (response.isSuccessful) {
                    statusMessage.postValue("Password reset successfully")
                    resetSuccess.postValue(true)
                } else {
                    statusMessage.postValue("Failed to reset password")
                }
            }

            override fun onFailure(call: Call<GenericResponse>, t: Throwable) {
                statusMessage.postValue("Network error: ${t.message}")
            }
        })
    }
}
