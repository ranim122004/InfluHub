package com.devision.influhub.authentication.model

data class VerifyOtpRequest(
    val Email: String,
    val otp: String
)
