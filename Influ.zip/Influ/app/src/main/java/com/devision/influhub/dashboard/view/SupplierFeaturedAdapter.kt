package com.devision.influhub.dashboard.view

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.devision.influhub.dashboard.model.FeaturedItem
import com.devision.influhub.R

class FeaturedSupplierAdapter(
    private val items: MutableList<FeaturedItem>,
    private val onViewAllClick: () -> Unit
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    private val VIEW_TYPE_ITEM = 0
    private val VIEW_TYPE_VIEW_ALL = 1

    override fun getItemViewType(position: Int): Int {
        return if (position < items.size) VIEW_TYPE_ITEM else VIEW_TYPE_VIEW_ALL
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return if (viewType == VIEW_TYPE_ITEM) {
            val view = LayoutInflater.from(parent.context)
                .inflate(R.layout.item_featured_supplier, parent, false)
            SupplierViewHolder(view)
        } else {
            val view = LayoutInflater.from(parent.context)
                .inflate(R.layout.item_view_all, parent, false)
            ViewAllViewHolder(view)
        }
    }

    override fun getItemCount(): Int = items.size + 1

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        if (holder is SupplierViewHolder && position < items.size) {
            val item = items[position]
            Glide.with(holder.itemView)
                .load(item.image)
                .into(holder.image)
            holder.name.text = item.username
        } else if (holder is ViewAllViewHolder) {
            holder.itemView.setOnClickListener { onViewAllClick() }
        }
    }

    fun updateList(newItems: List<FeaturedItem>) {
        items.clear()
        items.addAll(newItems)
        notifyDataSetChanged()
    }

    class SupplierViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val image: ImageView = view.findViewById(R.id.image)
        val name: TextView = view.findViewById(R.id.username)
    }

    class ViewAllViewHolder(view: View) : RecyclerView.ViewHolder(view)
}
