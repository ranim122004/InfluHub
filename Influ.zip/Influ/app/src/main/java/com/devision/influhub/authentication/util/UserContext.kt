package com.devision.influhub.util

object UserContext {

    private val properties = mutableMapOf<String, String>()

    fun setProperty(key: String, value: String) {
        properties[key] = value
    }

    fun getProperty(key: String): String? {
        return properties[key]
    }

    fun clear() {
        properties.clear()
    }
}
