package com.devision.influhub.dashboard.view

import android.content.Context
import android.os.Bundle
import android.text.InputType
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.devision.influhub.databinding.ChangePasswordFragmentBinding
import com.devision.influhub.network.RetrofitBuilder
import okhttp3.ResponseBody
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class ChangePasswordFragment : Fragment() {

    private var _binding: ChangePasswordFragmentBinding? = null
    private val binding get() = _binding!!

    private var isOldPasswordVisible = false
    private var isNewPasswordVisible = false

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = ChangePasswordFragmentBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.oldPasswordToggle.setOnClickListener {
            isOldPasswordVisible = !isOldPasswordVisible
            val inputType = if (isOldPasswordVisible)
                InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
            else
                InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD

            binding.oldpassword.inputType = inputType
            binding.oldpassword.setSelection(binding.oldpassword.text?.length ?: 0)
        }

        binding.newPasswordToggle.setOnClickListener {
            isNewPasswordVisible = !isNewPasswordVisible
            val inputType = if (isNewPasswordVisible)
                InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
            else
                InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD

            binding.newpassword.inputType = inputType
            binding.newpassword.setSelection(binding.newpassword.text?.length ?: 0)
        }

        binding.submitbtn.setOnClickListener {
            val current = binding.oldpassword.text.toString().trim()
            val newPass = binding.newpassword.text.toString().trim()

            if (current.isEmpty() || newPass.isEmpty()) {
                Toast.makeText(requireContext(), "Both fields are required", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (current == newPass) {
                Toast.makeText(requireContext(), "New password must be different", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val sharedPref = requireContext().getSharedPreferences("user_pref", Context.MODE_PRIVATE)
            val userId = sharedPref.getString("userId", null)

            if (userId != null) {
                changePassword(userId, current, newPass)
            } else {
                Toast.makeText(requireContext(), "User ID not found. Please login again.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun changePassword(userId: String, oldPass: String, newPass: String) {
        val apiService = RetrofitBuilder.getApiService(requireContext())

        val passwordMap = mapOf(
            "oldPassword" to oldPass,
            "newPassword" to newPass
        )

        apiService.changePassword(userId, passwordMap)
            .enqueue(object : Callback<ResponseBody> {
                override fun onResponse(call: Call<ResponseBody>, response: Response<ResponseBody>) {
                    binding.buttonProgressBar.visibility = View.GONE
                    binding.submitbtn.text = "SUBMIT"
                    binding.submitbtn.isEnabled = true

                    if (response.isSuccessful) {
                        Toast.makeText(requireContext(), "Password changed successfully", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(requireContext(), "Failed to change password", Toast.LENGTH_SHORT).show()
                    }
                }

                override fun onFailure(call: Call<ResponseBody>, t: Throwable) {
                    binding.buttonProgressBar.visibility = View.GONE
                    binding.submitbtn.text = "SUBMIT"
                    binding.submitbtn.isEnabled = true

                    Toast.makeText(requireContext(), "Error: ${t.message}", Toast.LENGTH_SHORT).show()
                }
            })
    }


    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
