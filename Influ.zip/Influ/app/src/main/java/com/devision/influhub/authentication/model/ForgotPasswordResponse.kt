package com.devision.influhub.authentication.model

data class ForgotPasswordResponse(
    val message: String
)
