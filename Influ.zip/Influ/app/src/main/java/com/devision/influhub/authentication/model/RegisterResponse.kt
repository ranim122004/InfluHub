package com.devision.influhub.authentication.model

data class RegisterResponse(
    val message: String
)
