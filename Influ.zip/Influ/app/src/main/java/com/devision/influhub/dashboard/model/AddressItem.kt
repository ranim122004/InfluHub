package com.devision.influhub.dashboard.model

import java.io.Serializable

data class AddressItem(
    val _id: String,
    val nickname: String,
    val street: String,
    val phone_number: String,
    val building: String?,
    val apartment: String?,
    val latitude: Double,
    val longitude: Double
) : Serializable

