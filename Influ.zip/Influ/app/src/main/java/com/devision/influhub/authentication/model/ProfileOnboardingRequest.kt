package com.devision.influhub.authentication.model

data class ProfileOnboardingRequest(
    val email: String,
    val username: String,
    val CountryCode: String,
    val PhoneNumber: String,
    val WorkType: String,
    val userType: String,
    val Industry: String,
    val Degree: String? = null,
    val isFreelancer: String? = null,
    val Type: String? = null,
    val Capital: String? = null,
    val DigitalPresence: String? = null
)
