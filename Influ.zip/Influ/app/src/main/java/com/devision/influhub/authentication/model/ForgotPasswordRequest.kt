package com.devision.influhub.authentication.model

data class ForgotPasswordRequest(
    val Email: String
)
