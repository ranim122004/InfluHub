package com.devision.influhub.dashboard.view

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import com.devision.influhub.dashboard.model.LastChanceModel
import com.devision.influhub.databinding.FragmentAllLastChanceBinding

class AllLastChanceFragment : Fragment() {

    private var _binding: FragmentAllLastChanceBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentAllLastChanceBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val lastChanceList =
            arguments?.getParcelableArrayList<LastChanceModel>(ARG_LAST_CHANCE_LIST) ?: emptyList()

        binding.allLastChanceRecyclerView.layoutManager = GridLayoutManager(requireContext(), 4)
        binding.allLastChanceRecyclerView.adapter = AllLastChanceAdapter(lastChanceList)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    companion object {
        private const val ARG_LAST_CHANCE_LIST = "LAST_CHANCE_LIST"

        fun newInstance(list: ArrayList<LastChanceModel>): AllLastChanceFragment {
            val fragment = AllLastChanceFragment()
            val args = Bundle()
            args.putParcelableArrayList(ARG_LAST_CHANCE_LIST, list)
            fragment.arguments = args
            return fragment
        }
    }
}
