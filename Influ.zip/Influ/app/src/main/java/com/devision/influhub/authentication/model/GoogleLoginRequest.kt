package com.devision.influhub.authentication.model

data class GoogleLoginRequest(
    val idToken: String
)
