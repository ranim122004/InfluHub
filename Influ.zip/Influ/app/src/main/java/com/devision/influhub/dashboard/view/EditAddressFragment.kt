package com.devision.influhub.dashboard.view

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.devision.influhub.dashboard.model.AddressItem
import com.devision.influhub.databinding.FragmentEditAddressBinding
import com.devision.influhub.network.RetrofitBuilder
import okhttp3.ResponseBody
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class EditAddressFragment : Fragment() {

    companion object {
        private const val ARG_ADDRESS = "address_item"

        fun newInstance(address: AddressItem): EditAddressFragment {
            val fragment = EditAddressFragment()
            val args = Bundle()
            args.putSerializable(ARG_ADDRESS, address)
            fragment.arguments = args
            return fragment
        }
    }

    private lateinit var binding: FragmentEditAddressBinding
    private lateinit var address: AddressItem

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            address = it.getSerializable(ARG_ADDRESS) as AddressItem
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        binding = FragmentEditAddressBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        binding.nicknameEditText.setText(address.nickname)
        binding.streetEditText.setText(address.street)
        binding.buildingEditText.setText(address.building ?: "")
        binding.apartmentEditText.setText(address.apartment ?: "")
        binding.phoneEditText.setText(address.phone_number)

        binding.saveButton.setOnClickListener {
            updateAddress()
        }

        binding.backButton.setOnClickListener {
            parentFragmentManager.popBackStack()
        }
    }

    private fun updateAddress() {
        val token = getToken() ?: return

        // NOTE: Your backend update route currently updates only: street, city, state, zipCode, country.
        // We’ll still send the extra fields (nickname/building/apartment/phone_number) for future compatibility,
        // but only 'street' is guaranteed to update with the current backend.
        val updatedBody = mapOf(
            "nickname" to binding.nicknameEditText.text.toString(),
            "street" to binding.streetEditText.text.toString(),
            "building" to binding.buildingEditText.text.toString(),
            "apartment" to binding.apartmentEditText.text.toString(),
            "phone_number" to binding.phoneEditText.text.toString()
        )

        RetrofitBuilder.getApiService(requireContext())
            .updateAddress("Bearer $token", address._id, updatedBody)
            .enqueue(object : Callback<ResponseBody> {
                override fun onResponse(call: Call<ResponseBody>, response: Response<ResponseBody>) {
                    if (response.isSuccessful) {
                        Toast.makeText(requireContext(), "Address updated", Toast.LENGTH_SHORT).show()
                        parentFragmentManager.popBackStack()
                    } else {
                        Toast.makeText(requireContext(), "Failed to update address", Toast.LENGTH_SHORT).show()
                    }
                }

                override fun onFailure(call: Call<ResponseBody>, t: Throwable) {
                    Toast.makeText(requireContext(), "Error: ${t.message}", Toast.LENGTH_SHORT).show()
                }
            })
    }

    private fun getToken(): String? {
        return requireContext()
            .getSharedPreferences("user_pref", Context.MODE_PRIVATE)
            .getString("token", null)
    }
}
