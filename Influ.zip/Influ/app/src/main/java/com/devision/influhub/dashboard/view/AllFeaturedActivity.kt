package com.devision.influhub.view

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import com.devision.influhub.dashboard.model.FeaturedItem
import com.devision.influhub.dashboard.view.AllFeaturedAdapter
import com.devision.influhub.databinding.FragmentAllFeaturedBinding

class AllFeaturedFragment : Fragment() {

    private var _binding: FragmentAllFeaturedBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentAllFeaturedBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val featuredList = arguments?.getParcelableArrayList<FeaturedItem>(ARG_FEATURED_LIST) ?: emptyList()
        binding.recyclerView.layoutManager = GridLayoutManager(requireContext(), 4)
        binding.recyclerView.adapter = AllFeaturedAdapter(featuredList)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    companion object {
        private const val ARG_FEATURED_LIST = "FEATURED_LIST"

        fun newInstance(featuredList: ArrayList<FeaturedItem>): AllFeaturedFragment {
            val fragment = AllFeaturedFragment()
            val args = Bundle()
            args.putParcelableArrayList(ARG_FEATURED_LIST, featuredList)
            fragment.arguments = args
            return fragment
        }
    }
}
