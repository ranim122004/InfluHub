// com/devision/influhub/authentication/model/SocialLoginResponse.kt
package com.devision.influhub.authentication.model

data class SocialLoginResponse(
    val user: SocialUserDto,
    val token: String
)

data class SocialUserDto(
    val _id: String? = null,
    val Email: String? = null,
    val username: String? = null,
    val userType: String? = null,
    val provider: String? = null,
    val social_id: String? = null,
    val image: String? = null
)
