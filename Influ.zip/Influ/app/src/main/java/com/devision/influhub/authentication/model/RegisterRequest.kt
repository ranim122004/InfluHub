package com.devision.influhub.authentication.model

data class RegisterRequest(
    val Email: String,
    val Password: String,
    val ConfirmPassword: String
)
