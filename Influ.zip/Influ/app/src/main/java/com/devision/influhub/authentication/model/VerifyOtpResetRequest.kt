package com.devision.influhub.authentication.model

data class VerifyOtpResetRequest(
    val Email: String,
    val otp: String
)
