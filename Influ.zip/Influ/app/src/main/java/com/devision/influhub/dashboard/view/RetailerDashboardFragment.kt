package com.devision.influhub.view

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.devision.influhub.R
import com.devision.influhub.authentication.model.*
import com.devision.influhub.dashboard.view.*
import com.devision.influhub.dashboard.model.*
import com.devision.influhub.databinding.FragmentRetailerDashboardBinding
import com.devision.influhub.network.RetrofitBuilder
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class RetailerDashboardFragment : Fragment() {

    private var userId: String? = null
    private var _binding: FragmentRetailerDashboardBinding? = null
    private val binding get() = _binding!!
    private var completedCalls = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        userId = arguments?.getString("userId")
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentRetailerDashboardBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        showLoader()
        completedCalls = 0

        binding.competitorsRecyclerView.layoutManager =
            LinearLayoutManager(requireContext(), LinearLayoutManager.HORIZONTAL, false)
        binding.recyclerFeatured.layoutManager =
            LinearLayoutManager(requireContext(), LinearLayoutManager.HORIZONTAL, false)
        binding.hotPicksRecyclerView.layoutManager =
            LinearLayoutManager(requireContext(), LinearLayoutManager.HORIZONTAL, false)
        binding.lastChanceRecyclerView.layoutManager =
            LinearLayoutManager(requireContext(), LinearLayoutManager.HORIZONTAL, false)

        userId?.let {
            fetchCompetitors(it)
            fetchFeatured(it)
            fetchHotPicks(it)
            fetchLastChance(it)
        } ?: showToast("User ID not found")

        binding.bottomNavigationView.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.menu_dashboard -> {}
                R.id.menu_x -> navigateTo(XFragment())
                R.id.menu_messages -> navigateTo(MessagesFragment())
                R.id.menu_more -> navigateTo(MoreFragment())
            }
            true
        }
    }

    private fun fetchCompetitors(userId: String) {
        val apiService = RetrofitBuilder.getApiService(requireContext())
        apiService.getCompetitorsForRetailer(userId).enqueue(object :
            Callback<List<CompetitorModel>> {
            override fun onResponse(
                call: Call<List<CompetitorModel>>,
                response: Response<List<CompetitorModel>>
            ) {
                if (response.isSuccessful) {
                    val competitors = response.body()?.filter {
                        it.username != "Lorem ipsum dolor sit amet, consectetur"
                    } ?: emptyList()
                    if (competitors.isNotEmpty()) {
                        val adapter = CompetitorAdapter(competitors)
                        binding.competitorsRecyclerView.adapter = adapter
                    }
                }
                hideLoaderWhenDone()
            }

            override fun onFailure(call: Call<List<CompetitorModel>>, t: Throwable) {
                Log.e("RetailerDashboard", "Competitor error: ${t.message}")
                hideLoaderWhenDone()
            }
        })
    }

    private fun fetchFeatured(userId: String) {
        val apiService = RetrofitBuilder.getApiService(requireContext())
        apiService.getFeatured(userId).enqueue(object : Callback<List<FeaturedItem>> {
            override fun onResponse(
                call: Call<List<FeaturedItem>>,
                response: Response<List<FeaturedItem>>
            ) {
                if (response.isSuccessful) {
                    val featuredItems = response.body()?.filter { it.id != null } ?: emptyList()
                    val adapter = FeaturedAdapter(featuredItems) {
                        val fragment = AllFeaturedFragment.newInstance(ArrayList(featuredItems))
                        parentFragmentManager.beginTransaction()
                            .replace(R.id.fragmentContainer, fragment)
                            .addToBackStack(null)
                            .commit()
                    }
                    binding.recyclerFeatured.adapter = adapter
                }
                hideLoaderWhenDone()
            }

            override fun onFailure(call: Call<List<FeaturedItem>>, t: Throwable) {
                Log.e("RetailerDashboard", "Featured error: ${t.message}")
                hideLoaderWhenDone()
            }
        })
    }

    private fun fetchHotPicks(userId: String) {
        val apiService = RetrofitBuilder.getApiService(requireContext())
        apiService.getHotPickedSuppliers(userId).enqueue(object : Callback<List<HotPicksModel>> {
            override fun onResponse(
                call: Call<List<HotPicksModel>>,
                response: Response<List<HotPicksModel>>
            ) {
                if (response.isSuccessful) {
                    val hotPicks = response.body()
                        ?.filter { it.username != "Lorem ipsum dolor sit amet, consectetur" }
                        ?.drop(1)
                        ?: emptyList()
                    if (hotPicks.isNotEmpty()) {
                        val adapter = HotPicksAdapter(hotPicks) {
                            val fragment = AllHotPicksFragment.newInstance(ArrayList(hotPicks))
                            parentFragmentManager.beginTransaction()
                                .replace(R.id.fragmentContainer, fragment)
                                .addToBackStack(null)
                                .commit()
                        }
                        binding.hotPicksRecyclerView.adapter = adapter
                    }
                }
                hideLoaderWhenDone()
            }

            override fun onFailure(call: Call<List<HotPicksModel>>, t: Throwable) {
                Log.e("RetailerDashboard", "Hot Picks error: ${t.message}")
                hideLoaderWhenDone()
            }
        })
    }

    private fun fetchLastChance(userId: String) {
        val apiService = RetrofitBuilder.getApiService(requireContext())
        apiService.getLastChance(userId).enqueue(object : Callback<List<LastChanceModel>> {
            override fun onResponse(
                call: Call<List<LastChanceModel>>,
                response: Response<List<LastChanceModel>>
            ) {
                if (response.isSuccessful) {
                    val lastChanceList = response.body()
                        ?.filter { it.username != "Lorem ipsum dolor sit amet, consectetur" }
                        ?.drop(1)
                        ?: emptyList()
                    if (lastChanceList.isNotEmpty()) {
                        val adapter = LastChanceAdapter(lastChanceList) {
                            val fragment = AllLastChanceFragment.newInstance(ArrayList(lastChanceList))
                            parentFragmentManager.beginTransaction()
                                .replace(R.id.fragmentContainer, fragment)
                                .addToBackStack(null)
                                .commit()
                        }
                        binding.lastChanceRecyclerView.adapter = adapter
                    }
                }
                hideLoaderWhenDone()
            }

            override fun onFailure(call: Call<List<LastChanceModel>>, t: Throwable) {
                Log.e("RetailerDashboard", "Last Chance error: ${t.message}")
                hideLoaderWhenDone()
            }
        })
    }

    private fun showLoader() {
        binding.scrollView.visibility = View.GONE
        binding.bottomNavigation.visibility = View.GONE
        binding.loaderView.visibility = View.VISIBLE
    }

    private fun hideLoaderWhenDone() {
        completedCalls++
        if (completedCalls == 4) {
            binding.loaderView.visibility = View.GONE
            binding.scrollView.visibility = View.VISIBLE
            binding.bottomNavigation.visibility = View.VISIBLE
        }
    }

    private fun navigateTo(fragment: Fragment) {
        parentFragmentManager.beginTransaction()
            .replace(R.id.fragmentContainer, fragment)
            .addToBackStack(null)
            .commit()
    }

    private fun showToast(message: String) {
        Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
