package com.devision.influhub.dashboard.view

import android.content.Context
import android.os.Bundle
import android.text.TextUtils
import android.util.Patterns
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.fragment.app.Fragment
import com.devision.influhub.R
import com.devision.influhub.network.RetrofitBuilder
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.MapView
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.ResponseBody
import org.json.JSONObject
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class AddressDetailsFragment : Fragment(), OnMapReadyCallback {

    private lateinit var nicknameField: EditText
    private lateinit var streetField: EditText
    private lateinit var buildingField: EditText
    private lateinit var apartmentField: EditText
    private lateinit var phoneField: EditText
    private lateinit var submitBtn: Button
    private lateinit var mapView: MapView

    private var googleMap: GoogleMap? = null
    private var latitude: Double = 0.0
    private var longitude: Double = 0.0

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        return inflater.inflate(R.layout.fragment_full_address, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        nicknameField = view.findViewById(R.id.nickname)
        streetField = view.findViewById(R.id.street)
        buildingField = view.findViewById(R.id.building)
        apartmentField = view.findViewById(R.id.apartment)
        phoneField = view.findViewById(R.id.phone)
        submitBtn = view.findViewById(R.id.submitbtn)
        mapView = view.findViewById(R.id.locationMapPreview)

        arguments?.let {
            latitude = it.getDouble("latitude", 0.0)
            longitude = it.getDouble("longitude", 0.0)
        }

        mapView.onCreate(savedInstanceState)
        mapView.getMapAsync(this)

        view.findViewById<View>(R.id.refineMapButton).setOnClickListener {
            parentFragmentManager.popBackStack()
        }

        submitBtn.setOnClickListener {
            if (validateFields()) {
                saveAddress()
            }
        }
    }

    override fun onMapReady(map: GoogleMap) {
        googleMap = map
        val selectedLocation = LatLng(latitude, longitude)
        googleMap?.apply {
            moveCamera(CameraUpdateFactory.newLatLngZoom(selectedLocation, 15f))
            addMarker(MarkerOptions().position(selectedLocation))
            uiSettings.isScrollGesturesEnabled = false
            uiSettings.isZoomGesturesEnabled = false
        }
    }

    private fun validateFields(): Boolean {
        if (TextUtils.isEmpty(nicknameField.text)) {
            nicknameField.error = "Nickname is required"
            return false
        }
        if (TextUtils.isEmpty(streetField.text)) {
            streetField.error = "Street is required"
            return false
        }
        if (TextUtils.isEmpty(phoneField.text)) {
            phoneField.error = "Phone number is required"
            return false
        }
        if (!Patterns.PHONE.matcher(phoneField.text).matches()) {
            phoneField.error = "Enter a valid phone number"
            return false
        }
        if (latitude == 0.0 || longitude == 0.0) {
            Toast.makeText(context, "Please select a valid location", Toast.LENGTH_SHORT).show()
            return false
        }
        return true
    }

    private fun saveAddress() {
        val token = getAuthToken()
        if (token.isEmpty()) {
            Toast.makeText(context, "Authentication token not found", Toast.LENGTH_SHORT).show()
            return
        }

        val jsonObject = JSONObject().apply {
            put("nickname", nicknameField.text.toString())
            put("street", streetField.text.toString())
            put("building", buildingField.text.toString())
            put("apartment", apartmentField.text.toString())
            put("phone_number", phoneField.text.toString())
            put("latitude", latitude)
            put("longitude", longitude)
        }

        val requestBody = jsonObject.toString()
            .toRequestBody("application/json".toMediaTypeOrNull())

        val apiService = RetrofitBuilder.getApiService(requireContext())

        submitBtn.isEnabled = false
        submitBtn.text = "Submitting..."

        apiService.saveAddress("Bearer $token", requestBody)
            .enqueue(object : Callback<ResponseBody> {
                override fun onResponse(call: Call<ResponseBody>, response: Response<ResponseBody>) {
                    submitBtn.isEnabled = true
                    submitBtn.text = "Confirm"

                    if (response.isSuccessful) {
                        Toast.makeText(context, "Address saved successfully", Toast.LENGTH_SHORT).show()
                        parentFragmentManager.popBackStack()
                    } else {
                        val error = response.errorBody()?.string()
                        Toast.makeText(context, "Failed to save address: $error", Toast.LENGTH_LONG).show()
                    }
                }

                override fun onFailure(call: Call<ResponseBody>, t: Throwable) {
                    submitBtn.isEnabled = true
                    submitBtn.text = "Confirm"
                    Toast.makeText(context, "Error: ${t.localizedMessage}", Toast.LENGTH_SHORT).show()
                }
            })
    }

    private fun getAuthToken(): String {
        val sharedPref = requireContext().getSharedPreferences("user_pref", Context.MODE_PRIVATE)
        return sharedPref.getString("token", "") ?: ""
    }

    override fun onResume() {
        super.onResume()
        mapView.onResume()
    }

    override fun onPause() {
        super.onPause()
        mapView.onPause()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        mapView.onDestroy()
    }

    override fun onLowMemory() {
        super.onLowMemory()
        mapView.onLowMemory()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        mapView.onSaveInstanceState(outState)
    }
}
