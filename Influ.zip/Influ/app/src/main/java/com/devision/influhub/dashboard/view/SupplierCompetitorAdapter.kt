package com.devision.influhub.authentication.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.devision.influhub.R
import com.devision.influhub.dashboard.model.CompetitorModel

class SupplierCompetitorAdapter(
    private var items: MutableList<CompetitorModel>,
    private val onViewAllClick: () -> Unit
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    private val VIEW_TYPE_ITEM = 0
    private val VIEW_TYPE_VIEW_ALL = 1

    override fun getItemCount(): Int {
        return if (items.size > 9) 10 else items.size
    }

    override fun getItemViewType(position: Int): Int {
        return if (position == 9 && items.size > 9) VIEW_TYPE_VIEW_ALL else VIEW_TYPE_ITEM
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return if (viewType == VIEW_TYPE_VIEW_ALL) {
            val view = LayoutInflater.from(parent.context)
                .inflate(R.layout.item_view_all, parent, false)
            ViewAllViewHolder(view)
        } else {
            val view = LayoutInflater.from(parent.context)
                .inflate(R.layout.item_competitor_supplier, parent, false)
            CompetitorViewHolder(view)
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        if (holder is CompetitorViewHolder) {
            val item = items[position]
            holder.bind(item)
        } else if (holder is ViewAllViewHolder) {
            holder.itemView.setOnClickListener { onViewAllClick() }
        }
    }

    fun updateList(newList: List<CompetitorModel>) {
        items = newList.toMutableList()
        notifyDataSetChanged()
    }

    class CompetitorViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        private val usernameText = view.findViewById<TextView>(R.id.username)
        private val imageView = view.findViewById<ImageView>(R.id.image)

        fun bind(item: CompetitorModel) {
            usernameText.text = item.username
            Glide.with(itemView.context).load(item.image).into(imageView)
        }
    }

    class ViewAllViewHolder(view: View) : RecyclerView.ViewHolder(view)
}

