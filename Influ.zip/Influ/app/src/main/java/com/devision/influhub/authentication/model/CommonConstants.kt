package com.devision.influhub.authentication.model

class CommonConstants {
    companion object {
        const val SUCCESS_CODE = "0x0000"
        const val INACTIVE_CODE = "0x0022"
        const val TRY_AGAIN = "0x0001"
        const val EXCEPTION_CODE = "0x0019"
        const val APPLICATION_ERROR_CODE = "0x9001"
        const val SESSION_MANAGEMENT_ERROR_CODE = "0x0021"
        const val BAD_REQUEST = "0x0400"
        const val NO_RECORD = "0x0009"
        const val ACCOUNT_ERROR = "0x9001"
        const val SERVICE_BUSINESS_ERROR = "0x0002"
    }
}
