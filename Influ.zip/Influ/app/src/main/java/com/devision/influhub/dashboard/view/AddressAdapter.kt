package com.devision.influhub.dashboard.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.devision.influhub.R
import com.devision.influhub.dashboard.model.AddressItem
import com.devision.influhub.databinding.AddressItemBinding

class AddressAdapter(
    private val addresses: List<AddressItem>,
    private val onEditClick: (AddressItem) -> Unit,
    private val onDeleteClick: (AddressItem) -> Unit
) : RecyclerView.Adapter<AddressAdapter.ViewHolder>() {

    inner class ViewHolder(val binding: AddressItemBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(item: AddressItem) {
            binding.addressNickname.text = item.nickname

            val details = listOfNotNull(
                item.street.takeIf { it.isNotBlank() },
                item.building?.takeIf { it.isNotBlank() },
                item.apartment?.takeIf { it.isNotBlank() }
            ).joinToString(", ")

            binding.addressDetails.text = details
            binding.addressPhone.text = item.phone_number
            binding.addressTypeIcon.setImageResource(R.drawable.address)

            binding.editAddress.setOnClickListener { onEditClick(item) }
            binding.deleteAddress.setOnClickListener { onDeleteClick(item) }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = AddressItemBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun getItemCount(): Int = addresses.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(addresses[position])
    }
}
