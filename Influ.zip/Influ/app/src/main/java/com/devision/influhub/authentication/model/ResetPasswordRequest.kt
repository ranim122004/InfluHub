package com.devision.influhub.authentication.model

data class ResetPasswordRequest(
    val Email: String,
    val newPassword: String
)
