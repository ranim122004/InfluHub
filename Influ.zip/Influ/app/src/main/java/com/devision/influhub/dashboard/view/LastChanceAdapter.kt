package com.devision.influhub.view

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.devision.influhub.R
import com.devision.influhub.dashboard.model.LastChanceModel

class LastChanceAdapter(
    private val items: List<LastChanceModel>,
    private val onViewAllClick: () -> Unit
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    companion object {
        private const val TYPE_ITEM = 0
        private const val TYPE_VIEW_ALL = 1
    }

    override fun getItemCount(): Int = items.take(9).size + 1

    override fun getItemViewType(position: Int): Int {
        return if (position < 9) TYPE_ITEM else TYPE_VIEW_ALL
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return if (viewType == TYPE_ITEM) {
            val view = LayoutInflater.from(parent.context)
                .inflate(R.layout.last_chance_item, parent, false)
            LastChanceViewHolder(view)
        } else {
            val view = LayoutInflater.from(parent.context)
                .inflate(R.layout.item_view_all, parent, false)
            ViewAllViewHolder(view, onViewAllClick)
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        if (holder is LastChanceViewHolder && position < 9) {
            holder.bind(items[position])
        }
    }

    class LastChanceViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val usernameTextView: TextView = itemView.findViewById(R.id.lastchanceName)
        private val imageView: ImageView = itemView.findViewById(R.id.lastchanceImage)       

        fun bind(item: LastChanceModel) {
            usernameTextView.text = item.username
            Glide.with(itemView.context).load(item.image).into(imageView)
        }
    }

    class ViewAllViewHolder(itemView: View, onClick: () -> Unit) : RecyclerView.ViewHolder(itemView) {
        init {
            itemView.setOnClickListener { onClick() }
        }
    }
}
