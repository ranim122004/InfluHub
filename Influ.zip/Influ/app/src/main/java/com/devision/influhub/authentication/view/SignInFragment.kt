package com.devision.influhub.authentication.view

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import com.devision.influhub.R
import com.devision.influhub.authentication.model.SocialLoginRequest
import com.devision.influhub.authentication.model.SocialLoginResponse
import com.devision.influhub.authentication.viewmodel.LoginViewModel
import com.devision.influhub.dashboard.view.SupplierDashboardFragment
import com.devision.influhub.databinding.ActivitySignInBinding
import com.devision.influhub.network.RetrofitBuilder
import com.devision.influhub.view.ForgotPasswordFragment
import com.devision.influhub.view.RetailerDashboardFragment
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import com.google.android.gms.tasks.Task
import com.google.gson.Gson

// Facebook SDK
import com.facebook.CallbackManager
import com.facebook.FacebookCallback
import com.facebook.FacebookException
import com.facebook.login.LoginManager
import com.facebook.login.LoginResult

import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class SignInFragment : Fragment() {

    private var _binding: ActivitySignInBinding? = null
    private val binding get() = _binding!!

    private var isPasswordVisible = false
    private val loginViewModel: LoginViewModel by viewModels()

    // Google
    private lateinit var googleClient: GoogleSignInClient

    // Facebook
    private lateinit var fbCallbackManager: CallbackManager

    private val googleLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            binding.googleProgress.visibility = View.GONE
            if (result.resultCode == Activity.RESULT_OK) {
                val task = GoogleSignIn.getSignedInAccountFromIntent(result.data)
                handleGoogleResult(task)
            } else {
                Toast.makeText(requireContext(), "Google sign-in cancelled", Toast.LENGTH_SHORT).show()
            }
        }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = ActivitySignInBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        configureGoogle()
        configureFacebook()
        loadSavedUsername()
        setupListeners()
        observeViewModel()
    }

    private fun loadSavedUsername() {
        val sp = requireActivity().getSharedPreferences("user_pref", Context.MODE_PRIVATE)
        val saved = sp.getString("saved_username", "")
        if (!saved.isNullOrEmpty()) binding.usernameEditText.setText(saved)
    }

    private fun setupListeners() {
        binding.showPasswordIcon.setOnClickListener {
            isPasswordVisible = !isPasswordVisible
            binding.passwordEditText.inputType =
                if (isPasswordVisible) InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
                else InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            binding.passwordEditText.setSelection(binding.passwordEditText.text?.length ?: 0)
        }

        binding.signinbtn.setOnClickListener {
            val username = binding.usernameEditText.text.toString().trim()
            val password = binding.passwordEditText.text.toString()
            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(requireContext(), "Please enter both username and password", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            startPrimaryButtonLoading(true)
            loginViewModel.login(requireContext(), username, password)
        }

        binding.signuplink.setOnClickListener {
            parentFragmentManager.beginTransaction()
                .replace(R.id.fragmentContainer, SignUpFragment())
                .addToBackStack(null)
                .commit()
        }

        binding.forgotPassword.setOnClickListener {
            val sp = requireActivity().getSharedPreferences("user_pref", Context.MODE_PRIVATE)
            val savedEmail = sp.getString("saved_email", "")
            val fragment = ForgotPasswordFragment().apply {
                arguments = Bundle().apply { putString("email", savedEmail) }
            }
            parentFragmentManager.beginTransaction()
                .replace(R.id.fragmentContainer, fragment)
                .addToBackStack(null)
                .commit()
        }

        // -------- Google button --------
        binding.googleSignIn.setOnClickListener {
            binding.googleProgress.visibility = View.VISIBLE
            // always show account chooser for fresh ID token
            googleClient.signOut().addOnCompleteListener {
                googleLauncher.launch(googleClient.signInIntent)
            }
        }

        // -------- Facebook button --------
        // Make sure your layout ImageView has id = facebookSignIn
        binding.facebookSignIn.setOnClickListener {
            // Request email so the backend can fetch it from Graph API
            LoginManager.getInstance().logInWithReadPermissions(
                this, listOf("public_profile", "email")
            )
        }
    }

    private fun observeViewModel() {
        loginViewModel.loginStatus.observe(viewLifecycleOwner) {
            Toast.makeText(requireContext(), it, Toast.LENGTH_SHORT).show()
        }
        loginViewModel.loginSuccess.observe(viewLifecycleOwner) { success ->
            startPrimaryButtonLoading(false)
            if (success) routeByUserType(loginViewModel.userType.value, loginViewModel.userId.value)
        }
    }

    private fun startPrimaryButtonLoading(loading: Boolean) {
        binding.buttonProgressBar.visibility = if (loading) View.VISIBLE else View.GONE
        binding.signinbtn.text = if (loading) "" else "SIGN IN"
        binding.signinbtn.isEnabled = !loading
    }

    private fun routeByUserType(type: String?, userId: String?) {
        when (type) {
            "Supplier" -> {
                val frag = SupplierDashboardFragment().apply {
                    arguments = Bundle().apply { putString("userId", userId) }
                }
                parentFragmentManager.beginTransaction().replace(R.id.fragmentContainer, frag).commit()
            }
            "Retailer" -> {
                val frag = RetailerDashboardFragment().apply {
                    arguments = Bundle().apply { putString("userId", userId) }
                }
                parentFragmentManager.beginTransaction().replace(R.id.fragmentContainer, frag).commit()
            }
            else -> Toast.makeText(requireContext(), "Signed in. Complete profile to continue.", Toast.LENGTH_SHORT).show()
        }
    }

    // ---------------- Google Sign-In ----------------

    private fun configureGoogle() {
        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestEmail()
            .requestIdToken(getString(R.string.google_web_client_id)) // <-- IMPORTANT
            .build()
        googleClient = GoogleSignIn.getClient(requireActivity(), gso)
    }

    private fun handleGoogleResult(task: Task<GoogleSignInAccount>) {
        try {
            val account = task.getResult(ApiException::class.java)
            if (account == null) {
                Toast.makeText(requireContext(), "Google account not found", Toast.LENGTH_SHORT).show()
                return
            }

            val idToken = account.idToken
            if (idToken.isNullOrEmpty()) {
                binding.googleProgress.visibility = View.GONE
                startPrimaryButtonLoading(false)
                AlertDialog.Builder(requireContext())
                    .setTitle("Google Login Failed")
                    .setMessage("Couldn’t obtain Google ID token. Check google_web_client_id.")
                    .setPositiveButton("OK", null)
                    .show()
                return
            }

            startPrimaryButtonLoading(true)
            binding.googleProgress.visibility = View.VISIBLE
            callBackendWithGoogleIdToken(idToken)

        } catch (e: ApiException) {
            Toast.makeText(requireContext(), "Google sign-in failed: ${e.statusCode}", Toast.LENGTH_LONG).show()
        }
    }

    private fun callBackendWithGoogleIdToken(idToken: String) {
        val api = RetrofitBuilder.getApiService(requireContext())
        val req = SocialLoginRequest(
            provider = "google",
            accessToken = idToken // backend expects this field name
        )

        api.socialLogin(req).enqueue(object : Callback<SocialLoginResponse> {
            override fun onResponse(
                call: Call<SocialLoginResponse>,
                response: Response<SocialLoginResponse>
            ) {
                binding.googleProgress.visibility = View.GONE
                startPrimaryButtonLoading(false)

                if (response.isSuccessful && response.body() != null) {
                    handleAuthSuccess(response.body()!!)
                } else {
                    val msg = response.errorBody()?.string() ?: response.message()
                    AlertDialog.Builder(requireContext())
                        .setTitle("Google Login Failed")
                        .setMessage(msg ?: "Unknown error")
                        .setPositiveButton("OK", null)
                        .show()
                }
            }

            override fun onFailure(call: Call<SocialLoginResponse>, t: Throwable) {
                binding.googleProgress.visibility = View.GONE
                startPrimaryButtonLoading(false)
                Toast.makeText(requireContext(), "Network error: ${t.message}", Toast.LENGTH_LONG).show()
            }
        })
    }

    // ---------------- Facebook Sign-In ----------------

    private fun configureFacebook() {
        fbCallbackManager = CallbackManager.Factory.create()

        LoginManager.getInstance().registerCallback(
            fbCallbackManager,
            object : FacebookCallback<LoginResult> {
                override fun onSuccess(result: LoginResult) {
                    val token = result.accessToken?.token
                    if (!token.isNullOrEmpty()) {
                        startPrimaryButtonLoading(true)
                        callBackendWithFacebookToken(token)
                    } else {
                        Toast.makeText(requireContext(), "Facebook token missing", Toast.LENGTH_SHORT).show()
                    }
                }
                override fun onCancel() {
                    Toast.makeText(requireContext(), "Facebook sign-in cancelled", Toast.LENGTH_SHORT).show()
                }
                override fun onError(error: FacebookException) {
                    Toast.makeText(requireContext(), "Facebook error: ${error.message}", Toast.LENGTH_LONG).show()
                }
            }
        )
    }

    private fun callBackendWithFacebookToken(fbAccessToken: String) {
        val api = RetrofitBuilder.getApiService(requireContext())
        val req = SocialLoginRequest(
            provider = "facebook",
            accessToken = fbAccessToken
            // email is optional; backend will fetch from Graph API if permission granted
        )

        api.socialLogin(req).enqueue(object : Callback<SocialLoginResponse> {
            override fun onResponse(
                call: Call<SocialLoginResponse>,
                response: Response<SocialLoginResponse>
            ) {
                startPrimaryButtonLoading(false)
                if (response.isSuccessful && response.body() != null) {
                    handleAuthSuccess(response.body()!!)
                } else {
                    val msg = response.errorBody()?.string() ?: response.message()
                    AlertDialog.Builder(requireContext())
                        .setTitle("Facebook Login Failed")
                        .setMessage(msg ?: "Unknown error")
                        .setPositiveButton("OK", null)
                        .show()
                }
            }

            override fun onFailure(call: Call<SocialLoginResponse>, t: Throwable) {
                startPrimaryButtonLoading(false)
                Toast.makeText(requireContext(), "Network error: ${t.message}", Toast.LENGTH_LONG).show()
            }
        })
    }

    // common success handling for Google/Facebook
    private fun handleAuthSuccess(payload: SocialLoginResponse) {
        val user = payload.user
        val token = payload.token

        val prefs = requireContext().getSharedPreferences("user_pref", Context.MODE_PRIVATE)
        prefs.edit().apply {
            putString("token", token)
            putString("userId", user._id ?: "")
            putString("userType", user.userType ?: "")
            putString("saved_email", user.Email ?: "")
            putString("saved_username", user.username ?: "")
            apply()
        }

        com.devision.influhub.util.UserContext.setProperty("profile", Gson().toJson(user))
        com.devision.influhub.util.UserContext.setProperty("accessToken", token)

        if (!user.userType.isNullOrEmpty()) {
            routeByUserType(user.userType, user._id)
        } else {
            AlertDialog.Builder(requireContext())
                .setTitle("Login")
                .setMessage("Login successful.\nComplete your profile to continue.")
                .setPositiveButton("OK", null)
                .show()
        }
    }

    // Facebook SDK requires forwarding activity result to CallbackManager
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (::fbCallbackManager.isInitialized) {
            fbCallbackManager.onActivityResult(requestCode, resultCode, data)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
