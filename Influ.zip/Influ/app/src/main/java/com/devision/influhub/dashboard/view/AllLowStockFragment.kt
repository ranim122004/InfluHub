package com.devision.influhub.dashboard.view

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import com.devision.influhub.dashboard.model.LowStockItem
import com.devision.influhub.databinding.FragmentAllLowStockBinding

class AllLowStockFragment : Fragment() {

    private var _binding: FragmentAllLowStockBinding? = null
    private val binding get() = _binding!!

    private lateinit var adapter: LowStockAdapter
    private lateinit var fullList: ArrayList<LowStockItem>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        fullList = arguments?.getParcelableArrayList("lowStockList") ?: arrayListOf()
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentAllLowStockBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        adapter = LowStockAdapter(fullList) {
            // No "View All" button needed here
        }
        binding.recyclerView.layoutManager = GridLayoutManager(requireContext(), 4)
        binding.recyclerView.adapter = adapter
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    companion object {
        fun newInstance(items: ArrayList<LowStockItem>): AllLowStockFragment {
            return AllLowStockFragment().apply {
                arguments = Bundle().apply {
                    putParcelableArrayList("lowStockList", items)
                }
            }
        }
    }
}
