package com.devision.influhub.dashboard.view

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.devision.influhub.R
import com.devision.influhub.dashboard.adapter.AddressAdapter
import com.devision.influhub.dashboard.model.AddressItem
import com.devision.influhub.databinding.FragmentAddressesBinding
import com.devision.influhub.network.RetrofitBuilder
import okhttp3.ResponseBody
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import com.devision.influhub.dashboard.model.AddressesResponse

class AddressesFragment : Fragment() {

    private var _binding: FragmentAddressesBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentAddressesBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.backIcon.setOnClickListener {
            requireActivity().onBackPressedDispatcher.onBackPressed()
        }

        // Button in empty state
        binding.btnaddress.setOnClickListener { goToMap() }

        // Button in list state
        binding.addAddressListBtn?.setOnClickListener { goToMap() }

        fetchAddresses()
    }

    override fun onResume() {
        super.onResume()
        // Refresh list when returning from add/edit screens
        fetchAddresses()
    }

    private fun fetchAddresses() {
        val token = getToken()
        if (token.isNullOrEmpty()) {
            showEmpty()
            Toast.makeText(requireContext(), "Please sign in again.", Toast.LENGTH_SHORT).show()
            return
        }

        val apiService = RetrofitBuilder.getApiService(requireContext())
        apiService.getUserAddresses("Bearer $token")
            .enqueue(object : Callback<AddressesResponse> {
                override fun onResponse(
                    call: Call<AddressesResponse>,
                    response: Response<AddressesResponse>
                ) {
                    when {
                        response.isSuccessful -> {
                            val list = response.body()?.addresses.orEmpty()
                            if (list.isNotEmpty()) showAddressList(list) else showEmpty()
                        }
                        response.code() == 404 -> {
                            // Backend returns 404 when user has no addresses
                            showEmpty()
                        }
                        response.code() == 401 || response.code() == 403 -> {
                            showEmpty()
                            Toast.makeText(requireContext(), "Session expired. Please login.", Toast.LENGTH_SHORT).show()
                        }
                        else -> {
                            showEmpty()
                            Toast.makeText(requireContext(), "Server error: ${response.code()}", Toast.LENGTH_SHORT).show()
                        }
                    }
                }

                override fun onFailure(call: Call<AddressesResponse>, t: Throwable) {
                    showEmpty()
                    Toast.makeText(requireContext(), "Failed to load addresses: ${t.localizedMessage}", Toast.LENGTH_LONG).show()
                }
            })
    }

    private fun showEmpty() {
        binding.emptyLayout.visibility = View.VISIBLE
        binding.addressesRecyclerView.visibility = View.GONE
        binding.addAddressListBtn?.visibility = View.GONE
    }

    private fun showAddressList(addresses: List<AddressItem>) {
        binding.emptyLayout.visibility = View.GONE
        binding.addressesRecyclerView.visibility = View.VISIBLE
        binding.addAddressListBtn?.visibility = View.VISIBLE

        binding.addressesRecyclerView.layoutManager = LinearLayoutManager(requireContext())
        binding.addressesRecyclerView.adapter = AddressAdapter(
            addresses,
            onEditClick = { address ->
                val fragment = EditAddressFragment.newInstance(address)
                parentFragmentManager.beginTransaction()
                    .replace(R.id.fragmentContainer, fragment)
                    .addToBackStack(null)
                    .commit()
            },
            onDeleteClick = { address ->
                deleteAddress(address._id)
            }
        )
    }

    private fun deleteAddress(addressId: String) {
        val token = getToken() ?: return

        val apiService = RetrofitBuilder.getApiService(requireContext())
        apiService.deleteAddress("Bearer $token", addressId)
            .enqueue(object : Callback<ResponseBody> {
                override fun onResponse(
                    call: Call<ResponseBody>,
                    response: Response<ResponseBody>
                ) {
                    if (response.isSuccessful) {
                        Toast.makeText(requireContext(), "Address deleted", Toast.LENGTH_SHORT).show()
                        fetchAddresses()
                    } else {
                        Toast.makeText(requireContext(), "Failed to delete address", Toast.LENGTH_SHORT).show()
                    }
                }

                override fun onFailure(call: Call<ResponseBody>, t: Throwable) {
                    Toast.makeText(requireContext(), "Error deleting address: ${t.localizedMessage}", Toast.LENGTH_LONG).show()
                }
            })
    }

    private fun goToMap() {
        parentFragmentManager.beginTransaction()
            .replace(R.id.fragmentContainer, MapAddressesFragment())
            .addToBackStack(null)
            .commit()
    }

    private fun getToken(): String? {
        // Use the same prefs where LoginViewModel saves "token"
        return requireContext()
            .getSharedPreferences("user_pref", Context.MODE_PRIVATE)
            .getString("token", null)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
