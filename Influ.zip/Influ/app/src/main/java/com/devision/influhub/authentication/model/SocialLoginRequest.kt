// com/devision/influhub/authentication/model/SocialLoginRequest.kt
package com.devision.influhub.authentication.model

data class SocialLoginRequest(
    val provider: String,          // "google" or "facebook"
    val accessToken: String,       // OAuth access token
    val email: String? = null      // only needed when FB doesn't provide email
)
