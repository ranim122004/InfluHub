package com.devision.influhub.dashboard.model

data class CompetitorModel(
    val _id: String,
    val image: String,
    val username: String,
    val Industry: String
)
