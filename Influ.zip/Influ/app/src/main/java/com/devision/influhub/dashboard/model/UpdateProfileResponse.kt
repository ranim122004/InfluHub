package com.devision.influhub.dashboard.model

data class UpdateProfileResponse(
    val message: String,
    val data: UserProfile
)

data class UserProfile(
    val userId: String,
    val username: String,
    val firstName: String,
    val lastName: String,
    val email: String,
    val image: String,
    val phoneNumber: String
)
