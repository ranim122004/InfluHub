package com.devision.influhub.authentication.view

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.RadioButton
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import com.devision.influhub.R
import com.devision.influhub.authentication.model.ProfileOnboardingRequest
import com.devision.influhub.authentication.viewmodel.ProfileOnboardingViewModel
import com.devision.influhub.databinding.FragmentProfileOnboardingBinding

class ProfileOnboardingFragment : Fragment() {

    private var _binding: FragmentProfileOnboardingBinding? = null
    private val binding get() = _binding!!
    private val profileOnboardingViewModel: ProfileOnboardingViewModel by viewModels()

    private var userEmail: String? = null
    private val countryCodes = listOf("+961")

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentProfileOnboardingBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        userEmail = arguments?.getString("email")

        setupCountryCode()
        setupRadioButtons()
        setupSubmitButton()
        observeOptions()

        profileOnboardingViewModel.fetchOptions(requireContext())

        binding.supplierIndustrySpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View?, position: Int, id: Long) {
                val selectedIndustry = parent.getItemAtPosition(position).toString()
                val typesList = profileOnboardingViewModel.industryMap[selectedIndustry] ?: emptyList()
                profileOnboardingViewModel.types.postValue(typesList)
            }

            override fun onNothingSelected(parent: AdapterView<*>) {}
        }
    }

    private fun setupCountryCode() {
        val adapter = ArrayAdapter(requireContext(), android.R.layout.simple_dropdown_item_1line, countryCodes)
        binding.countryCodeEditText.setAdapter(adapter)
        binding.countryCodeEditText.setText("+961", false)

        if (!userEmail.isNullOrEmpty()) {
            val username = userEmail!!.substringBefore("@")
            binding.usernameEditText.setText(username)
        }
    }

    private fun observeOptions() {
        profileOnboardingViewModel.industries.observe(viewLifecycleOwner) { industries ->
            val industryAdapter = ArrayAdapter(requireContext(), R.layout.spinner_dropdown_item, industries)
            binding.retailerIndustrySpinner.adapter = industryAdapter
            binding.supplierIndustrySpinner.adapter = industryAdapter
        }

        profileOnboardingViewModel.degrees.observe(viewLifecycleOwner) { degrees ->
            val degreeAdapter = ArrayAdapter(requireContext(), R.layout.spinner_dropdown_item, degrees)
            binding.degreeSpinner.adapter = degreeAdapter
        }

        profileOnboardingViewModel.capitals.observe(viewLifecycleOwner) { capitals ->
            val capitalAdapter = ArrayAdapter(requireContext(), R.layout.spinner_dropdown_item, capitals)
            binding.capitalSpinner.adapter = capitalAdapter
        }

        profileOnboardingViewModel.types.observe(viewLifecycleOwner) { types ->
            val typeAdapter = ArrayAdapter(requireContext(), R.layout.spinner_dropdown_item, types)
            binding.typeSpinner.adapter = typeAdapter
        }
    }

    private fun setupRadioButtons() {
        binding.userTypeGroup.setOnCheckedChangeListener { _, checkedId ->
            when (checkedId) {
                R.id.retailerOption -> {
                    binding.retailerLayout.visibility = View.VISIBLE
                    binding.supplierLayout.visibility = View.GONE
                }
                R.id.supplierOption -> {
                    binding.supplierLayout.visibility = View.VISIBLE
                    binding.retailerLayout.visibility = View.GONE
                }
            }
        }
    }

    private fun setupSubmitButton() {
        binding.continueButton.setOnClickListener {
            val username = binding.usernameEditText.text.toString().trim()
            val countryCode = binding.countryCodeEditText.text.toString().trim()
            val phoneNumber = binding.phoneEditText.text.toString().trim()
            val selectedId = binding.userTypeGroup.checkedRadioButtonId

            if (username.isEmpty() || countryCode.isEmpty() || phoneNumber.isEmpty() || selectedId == -1) {
                Toast.makeText(requireContext(), "Please fill in all required fields", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val selectedRadio = binding.userTypeGroup.findViewById<RadioButton>(selectedId)
            val userType = selectedRadio.text.toString()

            if (userType == "Supplier") {
                if (binding.supplierIndustrySpinner.selectedItem == null ||
                    binding.typeSpinner.selectedItem == null ||
                    binding.capitalSpinner.selectedItem == null ||
                    (!binding.digitalPresenceYes.isChecked && !binding.digitalPresenceNo.isChecked)
                ) {
                    Toast.makeText(requireContext(), "Please fill in all supplier fields", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }

                val request = ProfileOnboardingRequest(
                    email = userEmail ?: "",
                    username = username,
                    CountryCode = countryCode,
                    PhoneNumber = phoneNumber,
                    WorkType = "Business Owner",
                    userType = "Supplier",
                    Industry = binding.supplierIndustrySpinner.selectedItem.toString(),
                    Type = binding.typeSpinner.selectedItem.toString(),
                    Capital = binding.capitalSpinner.selectedItem.toString(),
                    DigitalPresence = if (binding.digitalPresenceYes.isChecked) "Yes" else "No"
                )
                submitProfile(request)

            } else if (userType == "Retailer") {
                if (binding.retailerIndustrySpinner.selectedItem == null ||
                    binding.degreeSpinner.selectedItem == null ||
                    (!binding.freelancerYes.isChecked && !binding.freelancerNo.isChecked)
                ) {
                    Toast.makeText(requireContext(), "Please fill in all retailer fields", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }

                val request = ProfileOnboardingRequest(
                    email = userEmail ?: "",
                    username = username,
                    CountryCode = countryCode,
                    PhoneNumber = phoneNumber,
                    WorkType = "Business Owner",
                    userType = "Retailer",
                    Industry = binding.retailerIndustrySpinner.selectedItem.toString(),
                    Degree = binding.degreeSpinner.selectedItem.toString(),
                    isFreelancer = if (binding.freelancerYes.isChecked) "Yes" else "No"
                )
                submitProfile(request)
            }
        }
    }

    private fun submitProfile(request: ProfileOnboardingRequest) {
        binding.buttonProgressBar.visibility = View.VISIBLE
        binding.continueButton.text = ""
        binding.continueButton.isEnabled = false

        profileOnboardingViewModel.submitProfile(requireContext(), request)

        profileOnboardingViewModel.isSuccess.observe(viewLifecycleOwner) { success ->
            binding.buttonProgressBar.visibility = View.GONE
            binding.continueButton.text = "SUBMIT"
            binding.continueButton.isEnabled = true

            if (success == true) {
                parentFragmentManager.beginTransaction()
                    .replace(R.id.fragmentContainer, Dashboard2Fragment())
                    .addToBackStack(null)
                    .commit()

                profileOnboardingViewModel.isSuccess.removeObservers(viewLifecycleOwner)
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
