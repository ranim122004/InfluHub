package com.devision.influhub.authentication.viewmodel

import android.content.Context
import android.util.Log
import android.widget.Toast
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.devision.influhub.authentication.model.ProfileOnboardingRequest
import com.devision.influhub.network.RetrofitBuilder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import retrofit2.HttpException

class ProfileOnboardingViewModel : ViewModel() {

    val isSuccess = MutableLiveData<Boolean>()
    val industries = MutableLiveData<List<String>>()
    val degrees = MutableLiveData<List<String>>()
    val capitals = MutableLiveData<List<String>>()
    val types = MutableLiveData<List<String>>()
    val industryMap = mutableMapOf<String, List<String>>()

    fun fetchOptions(context: Context) {
        val apiService = RetrofitBuilder.getApiService(context)

        apiService.getProfileOnboardingOptions().enqueue(object : retrofit2.Callback<Map<String, Any>> {
            override fun onResponse(
                call: retrofit2.Call<Map<String, Any>>,
                response: retrofit2.Response<Map<String, Any>>
            ) {
                if (response.isSuccessful && response.body() != null) {
                    val data = response.body()!!
                    Log.d("DEBUG", "Raw data: $data")

                    // Handle industries
                    val industriesRaw = data["industries"]
                    if (industriesRaw is List<*>) {
                        val industryList = industriesRaw.mapNotNull { item ->
                            (item as? Map<*, *>)?.get("industry") as? String
                        }
                        industries.postValue(industryList)

                        industriesRaw.forEach { item ->
                            val map = item as? Map<*, *>
                            val name = map?.get("industry") as? String ?: return@forEach
                            val typesList = map["type"] as? List<String> ?: emptyList()
                            industryMap[name] = typesList
                        }
                    } else {
                        Log.e("ProfileOnboardingVM", "Invalid format for industries: $industriesRaw")
                    }

                    // Handle degrees (expected: simple list)
                    val degreeRaw = data["degrees"]
                    if (degreeRaw is List<*>) {
                        val degreeList = degreeRaw.filterIsInstance<String>().drop(1)
                        degrees.postValue(degreeList)
                    } else {
                        Log.e("ProfileOnboardingVM", "Invalid format for degrees: $degreeRaw")
                    }

                    // Handle capitals (expected: simple list)
                    val capitalRaw = data["capitals"]
                    if (capitalRaw is List<*>) {
                        val capitalList = capitalRaw.filterIsInstance<String>().drop(1)
                        capitals.postValue(capitalList)
                    } else {
                        Log.e("ProfileOnboardingVM", "Invalid format for capitals: $capitalRaw")
                    }

                    Log.d("ProfileOnboardingVM", "Options loaded successfully")
                } else {
                    val errorMsg = "Failed to load options: ${response.message()}"
                    Toast.makeText(context, errorMsg, Toast.LENGTH_SHORT).show()
                    Log.e("ProfileOnboardingVM", errorMsg)
                }
            }

            override fun onFailure(call: retrofit2.Call<Map<String, Any>>, t: Throwable) {
                val errorMsg = "Network error: ${t.message}"
                Toast.makeText(context, errorMsg, Toast.LENGTH_SHORT).show()
                Log.e("ProfileOnboardingVM", errorMsg, t)
            }
        })
    }

    fun submitProfile(context: Context, request: ProfileOnboardingRequest) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val apiService = RetrofitBuilder.getApiService(context)
                val response = apiService.submitProfileOnboarding(request)

                withContext(Dispatchers.Main) {
                    Toast.makeText(context, "Profile submitted successfully", Toast.LENGTH_SHORT).show()
                    isSuccess.postValue(true)
                    Log.d("ProfileOnboardingVM", "Submission success: ${response.message}")
                }
            } catch (e: HttpException) {
                withContext(Dispatchers.Main) {
                    val msg = "HTTP error: ${e.message}"
                    Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                    Log.e("ProfileOnboardingVM", msg)
                    isSuccess.postValue(false)
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    val msg = "Unknown error: ${e.localizedMessage}"
                    Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                    Log.e("ProfileOnboardingVM", msg, e)
                    isSuccess.postValue(false)
                }
            }
        }
    }
}
