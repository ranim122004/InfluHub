package com.devision.influhub.view

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import com.devision.influhub.R
import com.devision.influhub.authentication.viewmodel.ForgotPasswordViewModel
import com.devision.influhub.databinding.ActivityForgotPasswordExchangeBinding

class VerifyOtpResetFragment : Fragment() {

    private var _binding: ActivityForgotPasswordExchangeBinding? = null
    private val binding get() = _binding!!
    private val viewModel: ForgotPasswordViewModel by viewModels()

    private var userEmail: String? = null

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = ActivityForgotPasswordExchangeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        userEmail = arguments?.getString("email")

        binding.backIcon.setOnClickListener {
            requireActivity().onBackPressedDispatcher.onBackPressed()
        }

        binding.continueButton.setOnClickListener {
            val otp = binding.emailEditText.text.toString().trim()

            if (otp.length != 6) {
                Toast.makeText(requireContext(), "Please enter the 6-digit OTP", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            binding.continueButton.text = ""
            binding.continueButton.isEnabled = false
            binding.verifyOtpProgressBar.visibility = View.VISIBLE

            viewModel.verifyOtp(requireContext(), userEmail ?: "", otp)
        }

        viewModel.statusMessage.observe(viewLifecycleOwner) { message ->
            Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show()

            binding.continueButton.text = "CONTINUE"
            binding.continueButton.isEnabled = true
            binding.verifyOtpProgressBar.visibility = View.GONE
        }

        viewModel.navigateToReset.observe(viewLifecycleOwner) { go ->
            if (go == true) {
                val fragment = ResetPasswordFragment()
                val bundle = Bundle()
                bundle.putString("email", userEmail)
                fragment.arguments = bundle

                parentFragmentManager.beginTransaction()
                    .replace(R.id.fragmentContainer, fragment)
                    .addToBackStack(null)
                    .commit()
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
