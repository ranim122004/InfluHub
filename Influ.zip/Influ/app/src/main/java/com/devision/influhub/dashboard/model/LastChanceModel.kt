package com.devision.influhub.dashboard.model

import android.os.Parcelable
import kotlinx.parcelize.Parcelize


@Parcelize
data class LastChanceModel(
    val id: String?,
    val username: String,
    val image: String
): Parcelable

