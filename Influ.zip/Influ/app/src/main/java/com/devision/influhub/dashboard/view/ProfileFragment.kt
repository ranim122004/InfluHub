package com.devision.influhub.dashboard.view

import android.app.AlertDialog
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import com.bumptech.glide.Glide
import com.devision.influhub.R
import com.devision.influhub.databinding.FragmentProfileBinding
import com.devision.influhub.network.RetrofitBuilder
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.ResponseBody
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.io.File
import java.io.FileOutputStream

class ProfileFragment : Fragment() {

    private var _binding: FragmentProfileBinding? = null
    private val binding get() = _binding!!
    private var selectedImageUri: Uri? = null

    private val pickImage = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri?.let {
            selectedImageUri = it
            Glide.with(this).load(it).into(binding.profileImage)
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentProfileBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.uploadButton.setOnClickListener {
            pickImage.launch("image/*")
        }

        binding.saveButton.setOnClickListener {
            selectedImageUri?.let { uploadProfile(it) }
        }

        binding.changePassword.setOnClickListener {
            parentFragmentManager.beginTransaction()
                .replace(R.id.fragmentContainer, ChangePasswordFragment())
                .addToBackStack(null)
                .commit()
        }

        binding.deletearrow.setOnClickListener {
            AlertDialog.Builder(requireContext())
                .setTitle("Delete Account")
                .setMessage("Are you sure you want to permanently delete your account?")
                .setPositiveButton("Yes") { _, _ -> deleteAccount() }
                .setNegativeButton("Cancel", null)
                .show()
        }
    }

    private fun deleteAccount() {
        val sharedPref = requireContext().getSharedPreferences("user_pref", Context.MODE_PRIVATE)
        val token = sharedPref.getString("token", null)

        if (token.isNullOrEmpty()) {
            Toast.makeText(requireContext(), "Missing token", Toast.LENGTH_SHORT).show()
            return
        }

        binding.deletearrow.visibility = View.GONE
        binding.deleteProgressBar.visibility = View.VISIBLE

        val apiService = RetrofitBuilder.getApiService(requireContext())
        apiService.deleteAccount("Bearer $token").enqueue(object : Callback<ResponseBody> {
            override fun onResponse(call: Call<ResponseBody>, response: Response<ResponseBody>) {
                binding.deletearrow.visibility = View.VISIBLE
                binding.deleteProgressBar.visibility = View.GONE

                if (response.isSuccessful) {
                    Toast.makeText(requireContext(), "Account deleted successfully", Toast.LENGTH_LONG).show()
                    // Optionally clear shared preferences or navigate
                } else {
                    val errorMsg = response.errorBody()?.string() ?: "Unknown error"
                    Log.e("DeleteAccount", "Error code: ${response.code()} - $errorMsg")
                    Toast.makeText(requireContext(), "Error deleting account", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onFailure(call: Call<ResponseBody>, t: Throwable) {
                binding.deletearrow.visibility = View.VISIBLE
                binding.deleteProgressBar.visibility = View.GONE
                Toast.makeText(requireContext(), "Error: ${t.message}", Toast.LENGTH_LONG).show()
            }
        })
    }


    private fun uploadProfile(imageUri: Uri) {
        val inputStream = requireContext().contentResolver.openInputStream(imageUri)
        val file = File(requireContext().cacheDir, "profile_image.jpg")
        val outputStream = FileOutputStream(file)
        inputStream?.copyTo(outputStream)
        inputStream?.close()
        outputStream.close()

        val requestFile = file.asRequestBody("image/*".toMediaTypeOrNull())
        val imagePart = MultipartBody.Part.createFormData("image", file.name, requestFile)

        val firstName = binding.firstname.text.toString().trim()
        val lastName = binding.lastname.text.toString().trim()

        if (firstName.isEmpty() || lastName.isEmpty()) {
            Toast.makeText(requireContext(), "Please fill in all fields", Toast.LENGTH_SHORT).show()
            return
        }

        val firstNameBody = RequestBody.create("text/plain".toMediaTypeOrNull(), firstName)
        val lastNameBody = RequestBody.create("text/plain".toMediaTypeOrNull(), lastName)

        val sharedPref = requireContext().getSharedPreferences("user_pref", Context.MODE_PRIVATE)
        val userId = sharedPref.getString("userId", null)

        if (userId.isNullOrEmpty()) {
            Toast.makeText(requireContext(), "User ID missing", Toast.LENGTH_SHORT).show()
            return
        }

        val apiService = RetrofitBuilder.getApiService(requireContext())

        binding.saveButton.text = ""
        binding.saveButton.isEnabled = false
        binding.verifyProgressBar.visibility = View.VISIBLE

        apiService.uploadProfileImage(imagePart, firstNameBody, lastNameBody, userId)
            .enqueue(object : Callback<ResponseBody> {
                override fun onResponse(call: Call<ResponseBody>, response: Response<ResponseBody>) {
                    binding.saveButton.text = "SAVE"
                    binding.saveButton.isEnabled = true
                    binding.verifyProgressBar.visibility = View.GONE

                    if (response.isSuccessful) {
                        AlertDialog.Builder(requireContext())
                            .setTitle("Success")
                            .setMessage("Profile updated successfully")
                            .setPositiveButton("OK", null)
                            .show()
                    } else {
                        Toast.makeText(requireContext(), "Upload failed", Toast.LENGTH_SHORT).show()
                    }
                }

                override fun onFailure(call: Call<ResponseBody>, t: Throwable) {
                    binding.saveButton.text = "SAVE"
                    binding.saveButton.isEnabled = true
                    binding.verifyProgressBar.visibility = View.GONE
                    Toast.makeText(requireContext(), "Error: ${t.message}", Toast.LENGTH_LONG).show()
                }
            })
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
