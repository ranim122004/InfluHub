package com.devision.influhub.dashboard.view

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.bumptech.glide.Glide
import com.devision.influhub.R
import com.devision.influhub.databinding.FragmentMoreBinding
import com.devision.influhub.dashboard.model.UserResponse
import com.devision.influhub.network.RetrofitBuilder
import com.devision.influhub.view.MessagesFragment
import com.devision.influhub.view.RetailerDashboardFragment
import com.devision.influhub.dashboard.view.SupplierDashboardFragment
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MoreFragment : Fragment() {

    private var _binding: FragmentMoreBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentMoreBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val sharedPref = requireContext().getSharedPreferences("user_pref", Context.MODE_PRIVATE)
        val userId = sharedPref.getString("userId", null)
        val userType = sharedPref.getString("userType", null)

        if (userId != null) {
            loadProfileImage(userId)
        }

        binding.btnprofile.setOnClickListener {
            uncheckBottomNav()
            val fragment: Fragment = when (userType?.lowercase()) {
                "supplier", "retailer" -> ProfileFragment()
                else -> {
                    Toast.makeText(context, "Invalid user type", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
            }

            parentFragmentManager.beginTransaction()
                .replace(R.id.fragmentContainer, fragment)
                .addToBackStack(null)
                .commit()
        }

        binding.btnlanguage.setOnClickListener {
            val sheet = LanguageBottomSheetFragment()
            sheet.show(childFragmentManager, "LanguageBottomSheet")
        }

        binding.btnaddress.setOnClickListener {
            parentFragmentManager.beginTransaction()
                .replace(R.id.fragmentContainer, AddressesFragment())
                .addToBackStack(null)
                .commit()
        }



        binding.bottomNavigationView.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.menu_dashboard -> {
                    if (userId != null && userType != null) {
                        val dashboardFragment: Fragment = when (userType.lowercase()) {
                            "supplier" -> SupplierDashboardFragment()
                            else -> RetailerDashboardFragment()
                        }

                        dashboardFragment.arguments = Bundle().apply {
                            putString("userId", userId)
                        }

                        parentFragmentManager.beginTransaction()
                            .replace(R.id.fragmentContainer, dashboardFragment)
                            .commit()
                    } else {
                        Toast.makeText(requireContext(), "User info not found", Toast.LENGTH_SHORT).show()
                    }
                    true
                }

                R.id.menu_messages -> {
                    parentFragmentManager.beginTransaction()
                        .replace(R.id.fragmentContainer, MessagesFragment())
                        .commit()
                    true
                }

                R.id.menu_x -> {
                    parentFragmentManager.beginTransaction()
                        .replace(R.id.fragmentContainer, XFragment())
                        .commit()
                    true
                }

                R.id.menu_more -> true
                else -> false
            }
        }

        binding.bottomNavigationView.selectedItemId = R.id.menu_more
    }

    private fun loadProfileImage(userId: String) {
        val apiService = RetrofitBuilder.getApiService(requireContext())
        apiService.getUserById(userId).enqueue(object : Callback<UserResponse> {
            override fun onResponse(call: Call<UserResponse>, response: Response<UserResponse>) {
                if (response.isSuccessful) {
                    val user = response.body()
                    user?.image?.let { imageBase64 ->
                        Glide.with(this@MoreFragment)
                            .load(imageBase64)
                            .placeholder(R.drawable.circle_blue_border)
                            .circleCrop()
                            .into(binding.profileImage)
                    }
                }
            }

            override fun onFailure(call: Call<UserResponse>, t: Throwable) {
                Toast.makeText(requireContext(), "Failed to load profile image", Toast.LENGTH_SHORT).show()
            }
        })
    }

    private fun uncheckBottomNav() {
        binding.bottomNavigationView.menu.setGroupCheckable(0, false, true)
        for (i in 0 until binding.bottomNavigationView.menu.size()) {
            binding.bottomNavigationView.menu.getItem(i).isChecked = false
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
