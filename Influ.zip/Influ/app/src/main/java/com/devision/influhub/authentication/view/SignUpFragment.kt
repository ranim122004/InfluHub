package com.devision.influhub.authentication.view

import android.app.AlertDialog
import android.content.Context
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.util.Log
import android.util.Patterns
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import com.devision.influhub.R
import com.devision.influhub.authentication.viewmodel.RegisterViewModel
import com.devision.influhub.databinding.ActivitySignUpBinding

class SignUpFragment : Fragment() {

    private var _binding: ActivitySignUpBinding? = null
    private val binding get() = _binding!!
    private val registerViewModel: RegisterViewModel by viewModels()

    private var isPasswordVisible = false
    private var isConfirmPasswordVisible = false

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = ActivitySignUpBinding.inflate(inflater, container, false)
        return binding.root
    }

    @RequiresApi(Build.VERSION_CODES.S)
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupListeners()
        observeViewModel()
    }

    @RequiresApi(Build.VERSION_CODES.S)
    private fun setupListeners() {
        binding.showPasswordIcon.setOnClickListener {
            isPasswordVisible = !isPasswordVisible
            togglePasswordVisibility(isPasswordVisible, isConfirm = false)
        }

        binding.showConfirmPasswordIcon.setOnClickListener {
            isConfirmPasswordVisible = !isConfirmPasswordVisible
            togglePasswordVisibility(isConfirmPasswordVisible, isConfirm = true)
        }

        binding.continueButton.setOnClickListener {
            val email = binding.emailEditText.text.toString().trim()
            val password = binding.passwordEditText.text.toString()
            val confirmPassword = binding.confirmPasswordEditText.text.toString()

            val passwordRegex = Regex("^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[!@#\$%^&*_]).{8,}$")

            when {
                email.isEmpty() || password.isEmpty() || confirmPassword.isEmpty() -> {
                    Toast.makeText(requireContext(), "Please fill in all fields", Toast.LENGTH_SHORT).show()
                }
                !Patterns.EMAIL_ADDRESS.matcher(email).matches() -> {
                    Toast.makeText(requireContext(), "Please enter a valid email address", Toast.LENGTH_SHORT).show()
                }
                password != confirmPassword -> {
                    Toast.makeText(requireContext(), "Passwords do not match", Toast.LENGTH_SHORT).show()
                }
                !passwordRegex.matches(password) -> {
                    Toast.makeText(
                        requireContext(),
                        "Password must contain at least 1 uppercase letter, 1 lowercase letter, 1 digit, and 1 special character",
                        Toast.LENGTH_LONG
                    ).show()
                }
                else -> {
                    // Disable button and show loader
                    binding.continueButton.text = ""
                    binding.continueButton.isEnabled = false
                    binding.registerProgressBar.visibility = View.VISIBLE

                    val username = email.substringBefore("@")
                    val sharedPref = requireActivity().getSharedPreferences("user_pref", Context.MODE_PRIVATE)
                    sharedPref.edit()
                        .putString("saved_email", email)
                        .putString("saved_username", username)
                        .apply()

                    registerViewModel.register(requireContext(), email, password, confirmPassword)
                }
            }
        }

        binding.signInLink.setOnClickListener {
            parentFragmentManager.beginTransaction()
                .replace(R.id.fragmentContainer, SignInFragment())
                .addToBackStack(null)
                .commit()
        }
    }

    private fun togglePasswordVisibility(isVisible: Boolean, isConfirm: Boolean) {
        val inputType = if (isVisible) {
            InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
        } else {
            InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }

        if (isConfirm) {
            binding.confirmPasswordEditText.inputType = inputType
            binding.confirmPasswordEditText.setSelection(binding.confirmPasswordEditText.text.length)
        } else {
            binding.passwordEditText.inputType = inputType
            binding.passwordEditText.setSelection(binding.passwordEditText.text.length)
        }
    }

    private fun observeViewModel() {
        registerViewModel.registrationStatus.observe(viewLifecycleOwner) { message ->
            Log.d("SignUpFragment", "Status: $message")
            Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show()

            // Restore UI
            binding.registerProgressBar.visibility = View.GONE
            binding.continueButton.text = "CONTINUE"
            binding.continueButton.isEnabled = true
        }

        registerViewModel.isSuccess.observe(viewLifecycleOwner) { success ->
            if (success) {
                showSuccessDialog()
            }
        }
    }

    private fun showSuccessDialog() {
        val email = binding.emailEditText.text.toString().trim()
        AlertDialog.Builder(requireContext())
            .setTitle("Registration Successful")
            .setMessage("OTP has been sent to your email. Click OK to verify your code.")
            .setPositiveButton("OK") { dialog, _ ->
                dialog.dismiss()
                val bundle = Bundle()
                bundle.putString("email", email)

                val verifyFragment = VerifyEmailFragment()
                verifyFragment.arguments = bundle

                parentFragmentManager.beginTransaction()
                    .replace(R.id.fragmentContainer, verifyFragment)
                    .addToBackStack(null)
                    .commit()
            }
            .setCancelable(false)
            .show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
